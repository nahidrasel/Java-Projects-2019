
/**
 * This program will convert a distance into different measurements
 *
 * @author (Nahid Mahmud)
 * @version (a version number or a date)
 */
import java.util.*;
public class task2
{
    public static void main(String[] args){
    
    //declare the variables of city,distance,miles,meter,feet,inch
    String city1,city2;
    double distance,miles,meters,feet,inches;
    Scanner keyboard=new Scanner(System.in);
    
    //Enter the name of the first city
    System.out.println("Please insert the name of the first city:");
    city1=keyboard.nextLine();
    
    //Enter the name of the second city
    System.out.println("Please insert the name of the second city:");
    city2=keyboard.nextLine();
    
    //Insert the distance between two cities
    System.out.println("Please insert the distance between "+city1+" and "+city2+" in Km:");
    distance=keyboard.nextDouble();
    
    //Calculate the distance from km to miles,meters,feet & inches
    miles=distance*0.621371;
    meters=distance*1000;
    feet=distance*3280.84;
    inches=distance*39370.079;
    
    //display the outputs of km to miles,meters,feet,inches
    System.out.println("The distance between " +   city1  +   " and " +   city2 +   " in Miles is:"+miles);
    System.out.println("The distance between "+   city1  +   " and " +   city2 +   " in meters is:"+meters);
    System.out.println("The distance between " +   city1  +   " and " +   city2 +   " in feet is:"+feet);
    System.out.println("The distance between "+   city1  +   " and " +   city2 +    " in inches is:"+inches);
    
}
}
