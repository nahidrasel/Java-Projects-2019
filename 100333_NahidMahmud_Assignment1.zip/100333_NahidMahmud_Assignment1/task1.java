
/**
 * This program will calculte the area and perimeter of some shapes.
 *
 * @author (Nahid Mahmud)
 * @version (a version number or a date)
 */
import java.util.*;
public class task1
{
    public static void main(String[] args){
       
       //declare the radius,area,perimeter,lenth,width and side of a circle,rectangular & square
       double radius,area,perimeter,length,width,side1;
       
       //Get the input from user of radius of a circle
       System.out.println("Enter the radius of circle:");
       Scanner keyboard=new Scanner(System.in);
       radius=keyboard.nextDouble();
       
       //calculate the area and perimeter of a circle
       area=3.1416*radius*radius;
       perimeter=2*3.1416*radius;
       
       //Display the output of area & perimeter of a circle 
       System.out.println("The area of circle is:"+area);
       System.out.println("The perimeter of circle is:"+perimeter);
       
       //Get the input from user of Length & Width of rectangular
       System.out.println("Enter the lenght of rectangular:");
       length=keyboard.nextDouble();
       System.out.println("Enter the width of rectangular:");
       width=keyboard.nextDouble();
       
       //Calculate the area & perimeter of the rectangular
       area=length*width;
       perimeter=2*length+2*width;
       
       //Display the output of area & perimeter of rectangular
       System.out.println("The area of rectangular is:"+area);
       System.out.println("The perimeter of rectangular is:"+perimeter);
       
       //Take the value of a side of a square from user
       System.out.print(" Enter the value of one side: ");
       side1=keyboard.nextDouble();
       
       //Calculate the area & perimeter of the square
       
       perimeter=4*side1;
       area=side1*side1;
       
       //Display the output of area & perimeter of the square
       System.out.println("The area of square is:"+area);
       System.out.println("The perimeter of square is:"+perimeter);
    }

}
