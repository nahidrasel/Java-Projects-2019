
public abstract class BankAccount {

}
