import java.util.Scanner;

public class Exercise3 {

	public static void main(String[] args) {
		System.out.println("90" + 10);
		try {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter number");
			String input = scan.nextLine();
			int number = Integer.parseInt(input);
			number = number + 10;
			System.out.println("You have entered:" + number);
		} catch (NumberFormatException e) {
			System.out.println("Check the text you have entered!!");
		}
		try {
			System.out.println("-----------------");
			int x = Integer.parseInt("12");
			x = x + 5;
			System.out.println(x);
		} catch (NumberFormatException e) {
			System.out.println("Check the text you have entered!!");
		}
	}

}
