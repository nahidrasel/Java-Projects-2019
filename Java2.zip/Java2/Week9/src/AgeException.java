
public class AgeException extends Exception {

	public AgeException() {
		super("This is my Age msg");
	}

	public AgeException(String msg) {
		super(msg);
	}
}
