
public class NahidException extends Exception {

	public NahidException() {
		super("This is my nmsg");
	}

	public NahidException(String msg) {
		super(msg);
	}
}

