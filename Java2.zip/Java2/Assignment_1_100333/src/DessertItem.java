
public class DessertItem {

	private String name;

	// constructor with one input
	public DessertItem(String name) {
		this.name = name;
	}

	// get method for variable name
	public String name() {
		return this.name;
	}

	// set method for variable name
	public void setName(String name) {
		this.name = name;
	}

	// to string methods
	public String toString() {
		return "Name: " + name;
	}

	public int getCost() {
		
		return 0;
	}

}
