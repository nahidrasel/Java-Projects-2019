
import java.util.Calendar;

public class Date {
	int days;

	int month;
	int day;
	int year;
	int leapyear;
	int monthcount;
	int dayOfYear;

	public Date() {
		this.month = 5;
		this.day = 1;
		this.year = 2;
	}

	public void dayspassed() { // https://code.sololearn.com/caIo4HxT7E89/#java
		Calendar cal = Calendar.getInstance();
		days = cal.get(Calendar.DAY_OF_YEAR);
		System.out.println("\nPassed days in the year: " + days);
		System.out.println(" ");
	}

	public void daysremaining() { // https://code.sololearn.com/caIo4HxT7E89/#java
		int left = 365 - days;
		System.out.println("Remaining days in the year:" + left);
	}

	// Override
	public String toString() {
		String compare;
		return "Date [month=" + month + ", day=" + day + ", year=" + year + ", leapyear=" + leapyear + ", monthcount= ";
	}

	public Date(int month, int day, int year) {
		this.month = month;
		this.day = day;
		this.year = year;
	}

	public void setMonth(int monthValue) {
		if (month > 0 && month <= 12) {
			month = monthValue;
		} else {
			this.month = 0;
		}
	}

	public int getMonth() {
		return month;
	}

	public void setDay(int dayValue) {
		if (day > 0 && day <= 31) {

			day = dayValue;
		} else
			this.day = 0;
	}

	public int getDay() {
		return day;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int yearValue) {
		if (year > 0 && year <= 2018) {
			year = yearValue;
		} else
			this.year = 0;
	}

	public int getyear() {
		return year;
	}

	public void leapyear() /* ref:website name */
	{
		if (year % 4 == 0 || year % 100 == 0 || year % 400 == 0) {
			System.out.println("Leap year:Yes");
		} else
			System.out.println("Not leap year");
	}

	public void monthcount() {
		if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
			System.out.println("Days in month: 31");
		} else if (month == 4 || month == 6 || month == 9 || month == 11) {
			System.out.println("Days in month: 30");
		} else if (month == 2) {
			if ((year % 400 == 0) || ((year % 4 == 0) && (year % 100 != 0))) {
				System.out.println("Days in month:29 ");
			} else
				System.out.println("Days in month: 28");
		}

	}

	public void compare() {
		Calendar.getInstance();
		if (year != Calendar.YEAR) {
			System.out.println("Not Same Year & DAte ");
		} else
			System.out.println("same year and date");
	}

}