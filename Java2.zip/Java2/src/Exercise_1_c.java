import java.util.Scanner;

public class Exercise_1_c {

	public static void main(String[] args) {
		String name;
		int integer;
		double floating;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter an integer:");
		integer=scan.nextInt();
		
		System.out.println("Enter a floating number:");
		floating=scan.nextDouble();
		double sum=integer+floating;
		
		scan.nextLine();
		System.out.println("What is your name:");
		name=scan.nextLine();
		
		System.out.println("Hi!"+name+"The sum of "+integer+"and"+floating+"is"+sum);
	}

}
		

	}

}
