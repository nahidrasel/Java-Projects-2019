import java.util.Scanner;
public class LoopStatement4 {

	public static void main(String[] args) {
		double add, mul ,sub,div;
		int operation;
		double num1=0,num2=0;
		double result=0;
		Scanner scan=new Scanner(System.in);
		
		do {
		System.out.println("1.Add\n 2.Sub\n 3.Mul\n 4.Div\n 0. for quit");
		
		System.out.println("Choose an operation:");
		operation=scan.nextInt();
		if(operation>=1 && operation<=4) {
			
		System.out.println("Enter the first number:");
		num1=scan.nextInt();
		System.out.println("Enter the second number:");
		num2=scan.nextInt();
		if(operation==1) {
			result=num1+num2;
			System.out.println(num1+ "+" + num2 + "=" +result);
		}
		else if (operation==2) {
			result=num1-num2;
			System.out.println(num1+ "+" + num2 + "=" +result);
		}
		else if (operation==3) {
			result=num1*num2;
			System.out.println(num1+ "+" + num2 + "=" +result);
		}
		else if (operation==4) {
			result=num1/num2;
			System.out.println(num1+ "+" + num2 + "=" +result);
		}
		else {
			System.out.println("invalid");
		}
		}
		}
	while (operation!=0);		
		
	}
}