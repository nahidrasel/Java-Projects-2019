import java.util.Scanner;

public class Excercise_1_b {

	public static void main(String[] args) {
		int num;
		int sum=0;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter three numbers:");
		for(int i=1;i<4;i++) {
		
		num=scan.nextInt();
			
		sum=sum+num;
		}
		System.out.println("The sum is :" +sum);
	}
}
