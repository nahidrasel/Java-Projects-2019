import java.util.Scanner;

public class LoopStatement2 {

	public static void main(String[] args) {
		int limit;
		
		Scanner scan = new Scanner(System.in);

		System.out.println("How many times would you like to input");
		limit = scan.nextInt();
		
		for (int row = 1; row <= limit; row++) {
			for(int column=1;column<=limit;column++) {
		System.out.print("#");
		}
		
		System.out.println(" ");
	}
}
}