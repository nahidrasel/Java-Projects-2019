import java.util.Scanner;

public class Excercise_1_a {

	public static void main(String[] args) {
		String name;
		int age;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("What is your name:");
		name=scan.nextLine();
		System.out.println("Hello"+name);
		
		System.out.println("What is your age:");
		age=scan.nextInt();
		System.out.println(age);
	}

}
