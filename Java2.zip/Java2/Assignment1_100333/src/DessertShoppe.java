import java.util.Scanner;

public class DessertShoppe {
	public final static double TAX_RATE = 6.5;		// 6.5%
	public final static String STORE_NAME = "M & M Dessert Shoppe";
	public final static int MAX_ITEM_NAME_SIZE = 25;
	public final static int COST_WIDTH = 6;
	double totalp;
	double totalc;
	double totalcc;
	double totalsa;
	
		public static void printMenu() {
			System.out.println(" Choose an Iteam");
			System.out.println("1- Candy");
			System.out.println("2- Cookie");
			System.out.println("3- Ice cream");
			System.out.println("4- Sundae");
			System.out.println("5- exit");
		}

		public void main(String[] args) {

			Scanner scan = new Scanner(System.in);
			System.out.println("Enter your name");
			
			String name = scan.nextLine();
			System.out.println("Hi, "+name);
			System.out.println("Welcome to ICL DESSERT SHOP");
			DessertItem[] list = new DessertItem[5];{
			
			
			
			
			for (int i = 0; i < list.length; i++) {
				
				System.out.println("which one you want to buy");
				
				int choice = scan.nextInt();
				

				if (choice == 1) {
					System.out.println("OK, you want Candy, How much pound you need? ");
					int pound = scan.nextInt();
					
					  totalcc=pound*2.5;

				}
				else if (choice == 2) {
					System.out.println("OK, you want Cookies, How many pieces you need? ");
					double  pieces = scan.nextDouble();
					totalp=pieces*2.0;

				}

				else if (choice == 3) {
					System.out.println("OK, you want Ice Cream, how many you need? ");
					int number = scan.nextInt();
					 totalc=number*3.5;
					
				}
				else if (choice == 4) {
					System.out.println("OK, you want sundae, how many you need? ");
					int number = scan.nextInt();
					 totalsa=number*4.5;
					 
						}
				else 
				System.out.println("--------------------------okay");

			double total= totalp+totalc+totalcc+totalsa;
			System.out.println("Total Amount to pay:"+total);
			double afterTax=(total*0.65)+total;
			
			System.out.println("After tax"+afterTax);
			System.out.println("Enter the amount of money to pay:"); 
			double pay=scan.nextDouble();
			 
			double remainder=pay-total;
			System.out.println("You will have "+remainder+ "back !! Enjoy");
			}
		}
	}
}