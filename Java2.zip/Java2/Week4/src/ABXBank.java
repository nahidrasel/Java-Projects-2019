
public class ABXBank {
	private String name;
	private int code;
	private int balance;

	public ABXBank() {
		this.name = "";
		this.code = 0;
		this.balance = 0;
	}

	public ABXBank(String name) {
		this.name = name;
		this.code = 0;
		this.balance = 0;
	}

	public ABXBank(String name, int code) {
		this.name = name;
		this.code = code;
		this.balance = 0;
	}

	public ABXBank(String name, int code, int balance) {
		this.name = name;
		this.code = code;
		this.balance = balance;
	}

	public String toString() {
		return "Name is:" + name + "\nCode is :" + code + "\nBalance is :" + balance;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public int getBalance() {
		return balance;
	}
}
