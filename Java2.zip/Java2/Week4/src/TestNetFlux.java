
public class TestNetFlux {

	public static void main(String[] args) {
		NetFlux s = new NetFlux();
		System.out.println(s);

	}

}
