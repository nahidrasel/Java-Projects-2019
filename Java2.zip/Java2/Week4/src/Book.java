
public class Book {
	private String title;
	private double price;
	private int quantity;
	private Author author;//HAS-A relationship
	
public String toString() {
		
		return title+ ",$"+ price+",("+quantity+")by\n"+author;
	}


	public Book() {
		this.title = "Unknown";
		this.price = 0;
		this.quantity = 0;
		this.author=author;
	
	}
	public Book(String title,double price, int quantity,Author author) {
		this.title = "Nahid";
		this.price = 0;
		this.quantity = 0;
		this.author=new Author();
		//this.author=new Author("John","John@gmail.com",'M');
	}
	public void settitle(String title) {
		this.title = title;
	}

	public String gettitle() {
		return title;
	}

	public void setprice(double price) {
		this.price=price;
	}

	public double getprice() {
		return price;
	}

	public void setquantity(int quantity) {
		this.quantity = quantity;
	}
	public int getquantity() {
		return quantity;
	}
	
	}
		