
public class TestStudent {
	public static void main(String[] args) {

				Address a1=new Address(21,"Tait","Auckland");
				
				Student s2=new Student(100333,"Nahid",a1);
				System.out.println(s2);
		}
		}