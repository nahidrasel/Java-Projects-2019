
public class NetFlux {
		private String email;
		private int month;
		private int amount;
		
		public String toString()
		{
			return "Email is "+email
					+"\nMonth  ="+month
					+"\nAmount ="+amount
					+"\nTotal amount = "+totalamount();
		}
		public NetFlux()
		{
			this.email=" ";
			this.month=2;
			this.amount=3;
		}
		public NetFlux(String email)
		{
			this.email=email;
			this.month=0;
			this.amount=0;
		}
		public NetFlux(String email,int month)
		{
			this.email=email;
			this.month=month;
			this.amount=0;
		}
		public NetFlux(String email,int month,int amount)
		{
			this.email=email;
			this.month=month;
			this.amount=amount;
		}
		public int totalamount()
		{
			return month*amount;
		}
		
	}

