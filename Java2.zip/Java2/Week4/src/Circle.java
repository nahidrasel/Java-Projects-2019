//class

  public class Circle{

	private double radius;
	private String color;
	
	//Override a method called "toString"
	public String toString() {
		return "Radius="+radius
				+"\nColor is :"+color
				+"\nArea= "+area()
				+"\nCircumference"+circumference();
				
	}

	// Constructor
	public Circle() {
		this.radius = 0;
		this.color = "Black";
	}

	public Circle(double radius) {
		this.radius = radius;
		this.color = " ";
	}

	public Circle( double radius,String color) {
		this.radius = radius;
		this.color = color;
	}

   //set & get
	public void setRadius(double radiusValue) {
		this.radius = radiusValue;
	}

	public double getRadius() {
		return radius;
	}

	public void setColor(String colorValue) {
		this.color = colorValue;
	}

	public String getColor() {
		return color;
	}

	public double area() {
		return Math.PI * radius * radius;

	}
   //Method for area & circumference
	public double circumference() {
		return 2 *Math.PI*radius;
	}
   //Print details method
	/* public void printDetails() {
		System.out.println("Radius:" + radius);
		System.out.println("Color: " + color);
		System.out.println("Area: " + area());
		System.out.println("Circumference: " + circumference());
	}
	*/
	}
