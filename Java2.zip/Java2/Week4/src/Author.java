
public class Author {
	private String name;
	private String email;
	private char gender;
	
	public boolean checkEmail() {
		  for(int i=0;i<email.length();i++) {
			  if(email.charAt(i)=='@') {
				  return true;
			  }
		}
		return false;
		}


	public String toString() {
		
		return ""+ name + " "+email + gender;
				
	}

	public Author() {
		this.name = "Nahid";
		this.email = "nhdraselgamil.com ";
		this.gender = 'M';
	}

	public Author(String name, String email, char gender) {
		this.name = name;
		this.email = "";
		this.gender = gender;
	}
	

	public void setName() {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public void setGender() {
		this.gender = gender;
	}

	public char getGender() {
		return gender;
	}
}