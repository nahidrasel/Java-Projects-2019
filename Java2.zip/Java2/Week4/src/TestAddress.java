
public class TestAddress {

		public static void main(String[] args) {
			Address a = new Address(21,"Tait","Auckland");
			System.out.println(a);
			System.out.println("---------------------");
		
	}
}
