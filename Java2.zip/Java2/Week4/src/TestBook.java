import java.util.*;

public class TestBook {
	public static void main(String[] args) {
		Book b = new Book();
		System.out.println(b);
		System.out.println("---------------------");
		
		Author a1=new Author("John","John@gmail.com",'M');
		Author a2=new Author("James","James@gmail.com",'M');
		Book b2=new Book("Java Programming ",20,100,a2);
		System.out.println(b2);
}
}