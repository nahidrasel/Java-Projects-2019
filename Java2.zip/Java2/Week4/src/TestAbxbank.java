
public class TestAbxbank {

	public static void main(String[] args) {

		ABXBank acc1 = new ABXBank();
		System.out.println(acc1);
		System.out.println("-----------");
		
		ABXBank acc2 = new ABXBank("John");
		System.out.println(acc2);
		System.out.println("-----------");
	
		ABXBank acc3 = new ABXBank("Amanda",456);
		System.out.println(acc3);
		System.out.println("-----------");
		
		ABXBank acc4 = new ABXBank("Mark",456,500);
		System.out.println(acc4);
		System.out.println("-----------");
		
	}

}