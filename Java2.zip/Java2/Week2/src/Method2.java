import java.util.*;

public class Method2 {
	public static String Month(int number) {
		String name = " ";
		switch (number) {
		case 1:
			name = "January";
			break;
		case 2:
			name = "February";
			break;
		case 3:
			name = "March";
			break;
		case 4:
			name = "April";
			break;
		case 5:
			name = "May";
			break;
		case 6:
			name = "June";
			break;
		case 7:
			name = "July";
			break;
		case 8:
			name = "August";
			break;
		case 9:
			name = "September";
			break;
		case 10:
			name = "October";
			break;
		case 11:
			name = "November";
			break;
		case 12:
			name = "December";
			break;
		default:

			name="Wrong input";
		}
		
		return name;
	}
	public static void main(String[] args) {

		System.out.println("Enter a number between 1 to 12 for month");
		Scanner scan = new Scanner(System.in);
		int number = scan.nextInt();
		System.out.println(Month(number));// calling the name
	}

}
