import java.util.Scanner;

public class MethodPrintArray {

	public static void printArray(int[] array) {
		for (int i = 0; i=array.length; i++) {
			System.out.println( array[i]+" ");
		}
		}

	public void main() {
		printArray(numbers));
	}
}
