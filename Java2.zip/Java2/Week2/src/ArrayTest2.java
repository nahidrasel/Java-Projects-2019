import java.util.*;
public class ArrayTest2 {

	public static void main(String[] args) {

		int i ;
		String[] names= {"John","Smith","Sarah","Amanda","Mike","Wedyan"};
		for(i=0;i<names.length;i++) {
			System.out.print (names[i] + " ");
		}
		System.out.println("\nPrint in reverse order>>>>> ");
		for(i=names.length-1 ;i>=0 ; i--) {
			System.out.print (names[i] + " ");
		}
	}
	}

