
import java.util.*;

public class MaxInArray {
	public static int findMax(int[] array) {
		// int min=array[0];

		int max = -100;
		;
		for (int i = 0; i < array.length; i++) {

			if (array[i] > max) {
				max = array[i];
			}
		}
		return max;
	}

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		int[] numbers = { 10, 20, 30, 50, 60, 70 };
		int m = findMax(numbers);
		System.out.println("Max is " + m);
	}
}

/*
 * if(array[i]<min) { min=array[i];
 * 
 * return min; }
 */