
import java.util.*;

public class MinInArray{
	public static int findMin(int[] array) {
		int min= array[0];
		;
		for (int i = 0; i < array.length; i++) {

			if (array[i] <min) {
				min = array[i];
			}
		}
		return min;
	}

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		int[] numbers = { 20, 20, 30, 50, 60, 70 };
		int m = findMin(numbers);
		System.out.println("Min is " + m);
	}
}

/*
 * if(array[i]<min) { min=array[i];
 * 
 * return min; }
 */

