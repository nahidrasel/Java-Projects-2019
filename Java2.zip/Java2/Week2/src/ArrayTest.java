import java.util.*;

public class ArrayTest {

	public static void main(String[] args) {
		int n;
		int i;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter the number of student:");
		n = scan.nextInt();

		float sum = 0;
		float average = 0;
		int[] grades = new int[n];
		for (i = 0; i < n; i++) {
			System.out.println("Enter the grade for student: ");
			grades[i] = scan.nextInt();
			sum = sum + grades[i];
			average = sum / grades.length;
		}
		int max = grades[0];
		int min = grades[0];
		for (i = 0; i < grades.length; i++) {
			if (grades[i] < min) {
				min = grades[i];
			} else {
				max = grades[i];
			}
		}
		System.out.println("average is :" + average);
		System.out.println("min is " + min);
		System.out.println("max is " + max);
		
		
		
		String[] names= {"John","Smith","Sarah","Amanda","Mike","Wedyan"};
		for(i=0;i<names.length;i++) {
			System.out.print (names[i] + " ");
		}
		for(i=6;i>=0;i--) {
			System.out.print (names[i]);
		}
	}

}