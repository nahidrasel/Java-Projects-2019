
public class Koala extends Animal {
	//overriding (in two classes)
	//the same method signature
	//but different code

	int age;
	public void thoughts() {
		System.out.println("I am a Koala, and I am so sleepy zzzz");
	}

	public void talk() {
		System.out.println("Hi from Koala");
	}

	public void eat() {
		System.out.println("Koala is eating " +getFavouriteFood());
	}
	public void sing() {
		System.out.println("Koala is singging");
}
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age=age;
	}

}

