import java.util.Scanner;

public class TestAnimal2 {
	public static void main(String[] args) {
		Animal a = new Animal();
		Kangaroo k = new Kangaroo();
		Animal m = new Emu();// polymorphism

		Scanner scan = new Scanner(System.in);
		Animal[] zoo = new Animal[5];
		int n;
		System.out.println("Choose an animal");
		System.out.println("1-Kangaroo , 2-Koala  , 3-Emu ,4-Cat");
		for (int i = 0; i < zoo.length; i++) {

			n = scan.nextInt();
			
			if (n == 1) {
				zoo[i] = new Kangaroo();
			} else if (n == 2) {
				zoo[i] = new Koala();
			} else if (n == 3) {
				zoo[i] = new Emu();
				
			} 
			else if(n==4) {
				zoo[i]=new Cat();
			}
			else
				System.out.println("wrong input");
		}
		for (int i = 0; i < zoo.length; i++) {
			zoo[i].thoughts();
			zoo[i].talk();
			System.out.println("---------------------");
		}
	}

}