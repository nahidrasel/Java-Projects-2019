
public class SavingsAccount extends BankAccount {
	private double interestRate;

	public SavingsAccount(String accountNo, String customerName, double balance, double interestRate) {
		super(accountNo, customerName, balance);
		this.interestRate = interestRate;
	}

	public String toString() {
		return super.toString() + "\nSaving account with interest rate" + interestRate + "%";
	}

	public void setLimit(double interestRate) {
		this.interestRate = interestRate;
	}

	public double getinterestRate() {
		return interestRate;
	}

}
