import java.util.*;
public class BankAccount {
	Scanner scan = new Scanner(System.in);
	private String accountNo;
	private String customerName;
	private double balance;

	public BankAccount(String accountNo, String customerName, double balance) {
		this.accountNo = accountNo;
		this.customerName = customerName;
		this.balance = balance;
	}

	public String toString() {
		return "Account Number:" + accountNo + " Name:" + customerName + " Balance:" + balance;
	}

	public void withdraw(double amount) {
		if (amount <= balance) {
			balance = balance - amount;
		}
	}

	public void deposit(double amount) {
		if (amount > 0)
			balance = balance + amount;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setcustomerName(String name) {
		this.customerName = name;
	}

	public String getcustomerName() {
		return customerName;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getBalance() {
		return balance;
	}
}