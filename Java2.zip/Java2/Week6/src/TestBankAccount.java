
public class TestBankAccount {

	public static void main(String[] args) {
		
		//Create an object from each class

		BankAccount b = new BankAccount("10201544", "NAHID", 10000);
		System.out.println(b);
		System.out.println("--------------------");

		SavingsAccount a = new SavingsAccount("20145595", "KESHAV", 20050, 150);
		System.out.println(a);
		System.out.println("--------------------");
		
		a.withdraw(500);
		System.out.println("Balance"+a.getBalance());
		System.out.println("----------------");

		CreditAccount c = new CreditAccount("204546545", "Mehedi", 1100,500);
		System.out.println(c);
		c.deposit(2600);
		System.out.println("Balance"+c.getBalance());
		System.out.println("--------------------");

	}

}
