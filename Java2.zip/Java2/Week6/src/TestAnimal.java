
public class TestAnimal {
	public static void main(String[] args) {
		// Create an object from each class

		Animal a = new Animal();
		a.thoughts();
		a.talk();
		System.out.println("--------------------");

		Kangaroo k = new Kangaroo();
		k.thoughts();
		k.talk();
		k.setFavouriteFood(" Tree leaves ");
		k.eat();
		k.jump();
		System.out.println(k.getFavouriteFood());
		System.out.println("---------------");

		Emu e = new Emu();
		e.thoughts();
		e.talk();
		e.sing();
		System.out.println("--------------------");

		Koala o = new Koala();
		o.thoughts();
		o.setFavouriteFood("Seed");
		o.talk();
		o.eat();
		o.setAge(45);
		System.out.println(o.getAge());
		System.out.println("End");

	}

}
