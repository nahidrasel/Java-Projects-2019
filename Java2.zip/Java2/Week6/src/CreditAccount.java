
public class CreditAccount extends BankAccount {
	private int limit;

	public CreditAccount(String accountNo, String customerName, double balance, int limit) {
		super(accountNo, customerName, balance);
	}

	public String toString() {
		return super.toString() + "\nCredit account limit is :"+limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getLimit() {
		return limit;
	}

}
