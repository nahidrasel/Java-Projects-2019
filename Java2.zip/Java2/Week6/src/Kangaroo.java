
public class Kangaroo extends Animal {
	private int age;
	//overriding (in two classes)
	//the same method signature
	//but different code

	public void thoughts() {
		System.out.println("I am an Kangaroo, and I like to bounce around a lot.");
	}

	public void talk() {
		System.out.println("Hi from Kangaroo");
	}

	public void eat() {
		System.out.println("Kangaroo is eating " +getFavouriteFood());
	}
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age=age;
	}


	public void jump() {
		System.out.println("I'm a kangaroo ,I can Jump");
	}

}
