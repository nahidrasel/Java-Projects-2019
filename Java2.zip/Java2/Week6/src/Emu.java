
public class Emu extends Animal {
	//overriding (in two classes)
	//the same method signature
	//but different code

	public void thoughts() {
		System.out.println("I am an Emu, and Do you like to big bird like me?");
	}

	public void talk() {
		System.out.println("Hi from Emu");
	}

	public void eat() {
		System.out.println("Emu is eating" +getFavouriteFood());
	}
	public void sing() {
		System.out.println("Emu is singging");
}
}