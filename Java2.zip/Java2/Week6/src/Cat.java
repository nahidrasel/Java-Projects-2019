	public class Cat extends Animal {
		//overriding (in two classes)
		//the same method signature
		//but different code

		public void thoughts() {
			System.out.println("I am a Cat, and I am so loving pet for people");
		}

		public void talk() {
			System.out.println("Hi from Cat");
		}


}
