
public class Ant extends Insect {

	String type;

	public Ant(String type, double size, String color) {
		super(size, color);
		this.type = type;
	}

	public String toString() {

		return super.toString() + "Type is " + type;
	}

	public void attack() {

		System.out.println("Ant is attacking");
	}

	public void moving() {

		System.out.println("Ant is moving");
	}

	public boolean isDengerous() {

		return false;
	}

	public boolean canFly() {

		return false;
	}

	public void findFood() {
		System.out.println("Ant is looking for food");
	}
}