
public class Mosquito extends Insect {

	private char bloodType;

	public Mosquito(char gender, double size, String color) {
		super(size, color);
		this.bloodType = gender;
	}

	public String toString() {

		return super.toString() + "The Blood type is :" +bloodType;
	}

	public void attack() {

		System.out.println("Mosquito is attacking");
	}

	public void moving() {

		System.out.println("Mosquito is moving");

	}

	public boolean isDengerous() {

		return true;
	}

	public boolean canFly() {

		return true;
	}
	public void drinksBlood() {
		System.out.println("Mosquito is drinking blood from a human body");
	}
	
	
}

