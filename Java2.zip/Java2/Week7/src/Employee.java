
public class Employee {
	private int ID;
	private String name;

	// Constructor with two inputs

	public Employee(int ID, String name) {
		this.ID = ID;
		this.name = name;
	}
	// override toString

	public String toString() {
		return "Employee [ID =" + ID + ", name =" + name + "]";
	}

	public void pay() {
		System.out.println(name + " will get paid!");
	}

	public int getID() {
		return ID;
	}

	public void setID(int ID) {
		this.ID = ID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}