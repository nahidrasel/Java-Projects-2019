
public class TestInsect {

	public static void main(String[] args) {
		Bee b = new Bee(45, 4, "red");
		b.attack();
		System.out.println("Bee can fly:" + b.canFly());
		System.out.println("Bee can be dengerous:" + b.isDengerous());
		b.moving();
		b.collectHoney();
		System.out.println(b);

		System.out.println("*****************************");

		Ant a = new Ant("Big", 4, "red");
		a.attack();
		System.out.println("Ant can fly:" + a.canFly());
		System.out.println("Ant can be dengerous:" + a.isDengerous());
		a.moving();
		a.findFood();
		System.out.println(a);
		System.out.println("////////////////////////");
		
		Mosquito m = new Mosquito("A", 4, "black");
		m.attack();
		System.out.println("Mosquito can fly: "+ m.canFly());
		System.out.println("Mosquito can be dengerous:" + m.isDengerous());
		m.moving();
		m.drinksBlood();
		System.out.println(m);

	}

}
