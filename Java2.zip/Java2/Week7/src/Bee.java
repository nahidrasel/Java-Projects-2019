
public class Bee extends Insect {
	int speed;

	public Bee(int speed, double size, String color) {
		super(size, color);
		this.speed = speed;
	}

	public String toString() {

		return super.toString() + "The speed is :" + speed + "km/hr";
	}

	public void attack() {

		System.out.println("Bee is attacking");
	}

	public void moving() {

		System.out.println("Bee is moving");
		;
	}

	public boolean isDengerous() {

		return true;
	}

	public boolean canFly() {

		return true;
	}
	public void collectHoney() {
		System.out.println("Bee is collecting honey");
}

		
	}