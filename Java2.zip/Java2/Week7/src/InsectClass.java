
public class InsectClass {

}
