
public class PartTime extends Employee {
	int hours;
	double rate;

	// override
	public String toString() {
		return super.toString() + "PartTime [Hours=  " + hours + " Rate = " + rate + "]";
	}

	public PartTime(int ID, String name, int hours, double rate) {
		super(ID, name);
		this.hours = hours;
		this.rate = rate;
	}

	public void pay() // method signature
	{
		System.out.println(getName() + " will be paid " + calcTotalPay());
	}

	public void calcBonus() {
		double res = (calcTotalPay() * 0.02);
		System.out.println("The bonus is $:" + res);
	}

	public void addHours(int amount) {
		hours = hours + amount;
	}

	public double calcTotalPay() {
		return hours * rate;
	}

	public void sethours(int hours) {
		this.hours = hours;
	}

	public int gethours() {
		return hours;
	}

	public void setrate(double rate) {
		this.rate = rate;
	}

	public double getrate() {
		return rate;
	}
}