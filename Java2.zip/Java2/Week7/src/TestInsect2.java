import java.util.Scanner;

	public class TestInsect2 {
		public static void printMenu() {
			System.out.println("Choose an Insect:");
			System.out.println("1-Bee , 2-Ant  , 3-Mosquito ");
		}
		public static void main(String[] args) {
			
			Scanner scan = new Scanner(System.in);
			Insect[] list = new Insect[5];
			System.out.println("Enter the size");
			double size=scan.nextDouble();
			scan.nextLine();
			
			System.out.println("Enter the color:");
			String color=scan.nextLine();
			printMenu();
			
			int choice=scan.nextInt();
			scan.nextLine();
			for (int i = 0; i < list.length; i++) {

				
				if (choice == 1) {
					System.out.println("Enter the speed");
					int speed = 0;
					list[i] = new Bee(speed, size,color);
				} 
				if (choice == 2) {
					System.out.println("Enter the type");
					String type=scan.nextLine();
					list[i] = new Ant(type ,size, color);
				} 
				if (choice == 3) {
					System.out.println("Enter the gender");
					char gender=scan.nextLine().charAt(0);
					list[i] = new Mosquito(gender,size, color);
				}
			}
			System.out.println("---------------------");
			for (int i = 0; i < list.length; i++) {
				System.out.println(list[i]);
				list[i].attack();
				System.out.println( "Can fly: "+ list[i].canFly());
				System.out.println("Is dengerous:"+list[i].isDengerous());
				list[i].moving();
				
				if(list[i] instanceof Bee) {
					((Bee) list[i]).collectHoney();
				}
				if(list[i] instanceof Ant) {
					((Ant) list[i]).findFood();
				}
				if(list[i] instanceof Mosquito) {
					((Mosquito) list[i]).drinksBlood();
				}
			}
				System.out.println("---------------------");
			for(int i=0;i<list.length;i++) {
				System.out.println(list[i]);
				list[i].attack();
				System.out.println("Can fly:"+list[i].canFly());
				System.out.println("Is dangerous "+list[i].isDengerous());
				list[i].moving();
				
				if(list[i] instanceof Bee) {
					((Bee) list[i]).collectHoney();
				}
				if(list[i] instanceof Ant) {
					((Ant) list[i]).findFood();
				}
				if(list[i] instanceof Mosquito) {
					((Mosquito) list[i]).drinksBlood();
				}
				System.out.println("-------------------");
				}
			}
	}

