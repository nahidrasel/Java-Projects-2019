
public abstract class Animal {
	private String name;
	public void sleep(int hour) {
		System.out.println("The animal will sleep for" + hour);
	}
	public Animal(String name) {
		this.name = name;
	}
	
	public abstract void makeNoise(); // abstract method

	public abstract void walk();

	public void eat() {
		System.out.println("Living thing is eating...");
	}

	// overload
	public void eat(String food) {
		System.out.println("Living thing like to eat" + food);
	}

	public String toString() {
		return "Name is :" + name;
	}
}
