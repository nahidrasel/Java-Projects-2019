
public class TestShape {
	public static void main(String[] args) {
		Circle c= new Circle(5,4,12);
		System.out.println(c);
		c.area();
		c.perimeter();
		System.out.println("----------------");
		
		Ractangle r=new Ractangle(2,3,6,8);
		System.out.println(r);
		r.area();
		r.perimeter();
		System.out.println("--------------------");
		
		EqTriangle e= new EqTriangle(3,9,7);
		System.out.println(e);
		e.area();
		e.perimeter();
		System.out.println("--------------------");
		
		Square s=new Square(3,5,7);
		System.out.println("---------------");
		s.area();
		s.perimeter();
		System.out.println("------------------");
		
	}
}
