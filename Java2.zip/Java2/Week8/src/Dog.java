
public class Dog extends Animal {

	public Dog(String name) {
		super(name);
	}

	public void makeNoise() {
		
		System.out.println("Bark ! Bark !");
	}

	//override
	public void walk() {
		System.out.println("");
		
	}
	public void calcHuman() {
		System.out.println("");
	}
	}
