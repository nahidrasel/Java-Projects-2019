import java.util.Scanner;

public class TestShape2 {
	public static void printMenu() {
		System.out.println("1-Circle");
		System.out.println("2-Rectangular");
		System.out.println("3-EqTriangle");
		System.out.println("4-Square");
		System.out.println("5-Quit");
		System.out.println("Choose the shape number");
	}
	public static void main(String[] args) {
		System.out.println(java.time.LocalDate.now());
		
		Scanner scan=new Scanner(System.in);
		int choice=0;
		do {
			printMenu();
			choice=scan.nextInt();
			if(choice>0 && choice<5) {
				System.out.println("Enter X coorinate");
				int Xcord=scan.nextInt();
				System.out.println("Enter Y coorinate");
				int Ycord=scan.nextInt();
				
				if(choice==1) {
					System.out.println("Enter the radius");
					int r =scan.nextInt();
					Circle c=new Circle(Xcord,Ycord,r);
					System.out.println(c); // to print the details
				}
				else if (choice==2) {
					System.out.println("Enter the height");
					int h=scan.nextInt();
					System.out.println("Enter the width");
					int w=scan.nextInt();
					Ractangle rec=new Ractangle (Xcord,Ycord,h,w);
					System.out.println(rec);
				}
				else if (choice==3) {
					System.out.println("Enter the side Length");
					int ss=scan.nextInt();
					EqTriangle ss= new EqTriangle(Xcord,Ycord,ss);
					System.out.println(ss);
			}
				else if (choice==4) {
					System.out.println("Enter the Side");
					int s=scan.nextInt();
					System.out.println(s);
				}
			}
			System.out.println("Logout");
		}
			while(choice>0&& choice<5);
		}
	}
	