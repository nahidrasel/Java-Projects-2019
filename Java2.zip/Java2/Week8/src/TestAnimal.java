
public class TestAnimal {
	public static void main(String[] args) {
		Dog d = new Dog("Max");
		d.makeNoise();
		d.walk();
		//System.out.println(d.calcHumanAge(2));
		System.out.println("-------------------");

		Cow c = new Cow("CC");
		c.makeNoise();
		c.walk();
		System.out.println("----------------");

		Cat t = new Cat("Kitty");
		t.makeNoise();
		t.walk();
		t.eat("Meat");
	}

}
