
public class Cat extends Animal {

	public Cat(String name) {
		super(name);
		
	}

	//Override
	public void makeNoise() {
		System.out.println("Mew!! Mew!!");
	}

	//Override
	public void walk() {
		System.out.println("");
		
	}
	

}
