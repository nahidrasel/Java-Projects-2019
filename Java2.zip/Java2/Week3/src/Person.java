
public class Person {
	// Variables
	String name;
	String address;
	int age;
	//default constructor
	public Person() {
		this.name="Unknown";
		this.address="";
		this.age=0;
		}
	public Person(String name) {
		this.name=name;
		this.address="Unknown";
		this.age=18;
	}
	public Person(String nameValue,String addValue) {
		this.name=nameValue;
		this.address=addValue;
		this.age=18;
	}
	public Person(String name,String address,int age) {
		this.name=name;
		this.address=address;
		this.age=age;
	}

	// Method
	public void printDetails() {
		System.out.println("Name:" +name);
		System.out.println("Address:" +address);
		System.out.println("Age:" +age);
	}

}
