import java.util.Scanner;

public class TestCar {

	public static void main(String[] args) {

				Scanner scan=new Scanner(System.in);
				Car s=new Car();
				
				System.out.println("Please Enter the car Registration Number:");
				s.regNo=scan.nextLine();
				
				System.out.println("Please Enter the car brand name:");
				s.brandName=scan.nextLine();
				System.out.println("Please Enter the car price:");
				s.price=scan.nextDouble();
				System.out.println("Please Enter the car color:");
				s.color=scan.nextLine();
				
				
				System.out.println("Please Enter the car price:");
				s.price=scan.nextDouble();
				

				System.out.println("_ _ _ _ _ _ _ _ _ ");
				s.printDetails();
				
			}

	}
