import java.util.*;

public class PersonInputAPP {

	public static void main(String[] args) {
		
		//Create an object
		//ClassName objectName=new ClassName();
		Scanner scan=new Scanner(System.in)
				;
		Person p=new Person();
		p.printDetails();
		
		p.name="Nahid";
		p.address="21 Tait St.";
		p.age=21;
		
		System.out.println("_ _ _ _ _ _ _ _ _ ");
		p.printDetails();
		
		
		Person s=new Person();
		
		System.out.println("Please Enter the person name:");
		s.name=scan.nextLine();
		
		System.out.println("Please Enter the person address:");
		s.address=scan.nextLine();
		
		System.out.println("Please Enter the person age:");
		s.age=scan.nextInt();
		
		System.out.println("_ _ _ _ _ _ _ _ _ ");
		s.printDetails();
		
	}

}
