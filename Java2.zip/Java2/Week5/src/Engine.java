
public class Engine {
	private double size;
	private String type;

	public String toString() {
		return "[" + "" + size  + "L " + type+"]";
	}

	public Engine(double size, String type) {
		this.size = size;
		this.type = type;
	}
	public void setsize(double size) {
		this.size = size;
	}

	public double getsize() {
		return size;
	}

	public void settype(String type) {
		this.type = type;
	}

	public String gettype() {
		return type;
	}

}
