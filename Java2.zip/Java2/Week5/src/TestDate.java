	import java.util.Scanner;

	public class TestDate {

				public static void main(String[] args) {
					Scanner scan=new Scanner (System.in);
					
					Date s1=new Date();
					
					System.out.println("--------");
					s1.setMonth(9);
					s1.setDay(9);
					s1.setYear(2016);
					s1.leapyear();
				printDetails(s1);
				s1.monthcount();
				/*
				System.out.println("--------");
				s1.setMinutes(254);
				s2.setSeconds(95);
				s2.setHours(6);
				s2.printDetails();
*/
		}

				private static void printDetails(Date s1) {
					// TODO Auto-generated method stub
					
				}
				
	}

