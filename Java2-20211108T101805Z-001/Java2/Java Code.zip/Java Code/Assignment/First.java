
/**
 *This program will calculate the area and the perimeter for some shapes
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class First
{
    public static void main(String[] args){
       //declare the radius of a circle
       double radius;
       
       //Enter the radius of circle
       System.out.println("Enter the radius of circle:");
       Scanner keyboard=new Scanner(System.in);
       radius=keyboard.nextInt();
       
       //calculate the area of circle
       double area=3.1416*radius*radius;
       System.out.println("The area of circle is:"+area);
       
       //calculate the perimeter of circle
       double perimeter=2*3.1416*radius;
       System.out.println("The perimeter of circle is:"+perimeter);
    
       //declare the length and wide of a rectangular
       double length,width;
       
       //Enter the radius of circle
       System.out.println("Enter the lenght of circle:");
       Scanner keyboard=new Scanner(System.in);
       radius=keyboard.nextInt();
       
       //calculate the area of circle
       double area=3.1416*radius*radius;
       System.out.println("The area of circle is:"+area);
       
       //calculate the perimeter of circle
       double perimeter=2*3.1416*radius;
       System.out.println("The perimeter of circle is:"+perimeter);
    
    }
//input one shape and calculate the output
}
