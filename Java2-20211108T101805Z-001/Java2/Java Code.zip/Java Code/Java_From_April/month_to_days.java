
/**
 * Write a description of class month_days here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class month_to_days
{ public static void main(String[] args)   {      
    Scanner keyboard = new Scanner(System.in);      
     int month;      
    System.out.println("Enter the month between[1-12]");      
    month = keyboard.nextInt();
    switch(month){
    case 4:
    case 6:
    case 9:
    case 11:
    System.out.println("30 days in the month");
    break;
    
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
    System.out.println("31 days in the month");
    break;
    
    case 2:
    System.out.println("28/29 days in the month");
    break; 
    
    default:
    System.out.println("Not a valid month");
    break;
}
}
}
