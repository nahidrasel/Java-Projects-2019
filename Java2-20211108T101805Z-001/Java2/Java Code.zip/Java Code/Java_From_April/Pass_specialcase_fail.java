
/**
 * Write a description of class Pass_specialcase_fail here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Pass_specialcase_fail {
    public static void main(String[] args)  
    {  
        int mark;
        
        Scanner keyboard = new Scanner(System.in);   
        System.out.print("Enter Your Exam Mark: "); 
        mark = keyboard.nextInt();   
        if (mark>=50)   {       
            System.out.println("Pass");  
        }  
        else   {
            boolean special;
            System.out.print("Special Exam?");   
            special=keyboard.nextBoolean();      
            if (special==true)       {          
                System.out.println("Special Exam");       
            }       
            else       {          
                System.out.println("Fail");       }   
            }
}
}