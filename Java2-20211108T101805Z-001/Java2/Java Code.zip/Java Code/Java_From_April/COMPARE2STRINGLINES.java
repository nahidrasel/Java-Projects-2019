
/**
 * Write a description of class COMPARE2STRINGLINES here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class COMPARE2STRINGLINES
{
    public static void main(String[] args)   {   
        
        String line1,line2;
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Enter the one Line:"); 
        line1= keyboard.nextLine(); 
        System.out.println("Enter the another Line:");      
        line2= keyboard.nextLine();
        
        if (line1.equals(line2)){
            System.out.println("The lines are same") ;
        }
            
        else {
            System.out.println("The lines are Different");
        }
    }
            
        }