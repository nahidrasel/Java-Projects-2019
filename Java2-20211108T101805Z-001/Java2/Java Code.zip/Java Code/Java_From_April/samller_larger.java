
/**
 * Write a description of class samller_larger here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
  import java.util.*;
public class samller_larger
{
    public static void main(String[] args)   {   
        
        int num1,num2;
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Enter the one number:"); 
        num1= keyboard.nextInt(); 
        System.out.println("Enter the another number:");      
        num2= keyboard.nextInt();
        
        if (num1>=num2)     {               
            System.out.println("The larger number is : " +num1);
        }
        else {
            System.out.println("The larger number is : " +num2);
        }
    }
    }