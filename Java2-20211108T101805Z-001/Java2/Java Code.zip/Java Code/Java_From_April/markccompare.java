
/**
 * Write a description of class markccompare here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class markccompare
{
    public static void main(String[] args)   {     
        int mark;      
        Scanner keyboard = new Scanner(System.in); 
        
        System.out.println("Please Enter Your Mark");
        mark=keyboard.nextInt();
             
        if (mark>=50)     {             
            System.out.println("Pass");
        }
        else{
            System.out.println("Fail");
        }
   
    }
}