
/**
 * Write a description of class age_compare here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class age_compare
{
    public static void main(String[] args)   {     
        int age;      
        Scanner keyboard = new Scanner(System.in); 
        
        System.out.println("Please Enter Your Age");
        age=keyboard.nextInt();
             
        if (age<=40)     {             
            System.out.println("Young");
        }
        else{
            System.out.println("Old");
        }
    }
            
            
    }