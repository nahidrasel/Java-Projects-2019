
/**
 * Write a description of class squash_court_booking here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class squash_court_booking{
    public static void main(String[] args)   {     
        final double RATE = 19.50;      
        Scanner keyboard = new Scanner(System.in);      
        System.out.println("Squash Court Booking");      
        System.out.print("Time (in hours): ");      
        double hours = keyboard.nextDouble();      
        System.out.print("Are you a guild member (yes/no): ");      
        String guildMember = keyboard.next();      
        double total = hours * RATE;      
        if (guildMember.equalsIgnoreCase("yes"))     {         
            total *= 0.5;      }      
            System.out.println("Cost of booking is: " + total);
        }
    }