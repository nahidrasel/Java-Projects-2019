
/**
 * Write a description of class Quiz_selectiondata_ here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class use_special_caseadd_mul_div_switch
{
   public static void main(String[] args){
   Scanner keyboard = new Scanner(System.in);      
     int x;
     int y;
     int result;
    System.out.println("Enter x");  
    x = keyboard.nextInt();
    System.out.println("Enter y");
    y = keyboard.nextInt();
    
    System.out.println("Enter the operation \n +. Add\n -.Sub\n  3.* mul\n  4. / div\n");
    char op = keyboard.nextLine();
    char ch = op.nextLine.charAt(0);
    switch(ch){
    case '+': result=x+y;
    System.out.println("The result is "+result);
    break;

    case '-':result=x-y;
    System.out.println("The result is "+result);
    break;
    case '*':result=x*y;
    System.out.println("The result is "+result);
    break;
    case '/':result=x/y;
    System.out.println("The result is "+result);
    break;
}
}
}
