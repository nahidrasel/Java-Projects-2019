
/**
 * Write a description of class Quiz_selectiondata_ here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class SwitchQuiz_selectiondata2_
{
   public static void main(){
       Scanner keyboard = new Scanner(System.in);      
     int x;      
    System.out.println("Enter the month between[1-12]");      
    x = keyboard.nextInt();
    switch(x){
    case 0:
    case 1:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    System.out.println("0 to 9");
    break;
     case 10:
    case 11:
    case 12:
    case 13:
    case 14:
    case 15:
    case 16:
    case 17:
    case 18:
    case 19:
    System.out.println("10 to 19");
    break;
     case 20:
    case 21:
    case 22:
    case 23:
    case 24:
    case 25:
    case 26:
    case 27:
    case 28:
    case 29:
    System.out.println("20 to 29");
    break;
    default:
    System.out.println("Non of these");
    break;
}
}
}
