
/**
 * Write a description of class Positivenrg here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Positiveneg 
{
    public static void main(){
        int num;
        System.out.println("Enter an integer number:");
        Scanner keyboard=new Scanner(System.in);
        num=keyboard.nextInt();
        
        if(num<0){
            System.out.println("Negative Number");
        }
        else if(num>0)
        {
            System.out.println("Positive Number");
        }
        else {
            System.out.println("Zero");
    }
}
}
        
        
        
        
        