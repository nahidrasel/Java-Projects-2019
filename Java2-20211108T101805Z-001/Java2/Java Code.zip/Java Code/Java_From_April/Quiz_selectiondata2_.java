
/**
 * Write a description of class Quiz_selectiondata_ here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Quiz_selectiondata2_
{
   public static void main(){
       int x;
       Scanner keyboard=new Scanner(System.in);
       x=keyboard.nextInt();
       if(x>=0 && x<=9){
           System.out.println("0 to 9");
        }
       else if(x>=10 && x<=19) {
            System.out.println("10 to 19");
       }
       else if(x>=20 && x<=29) {
            System.out.println("20 to 29");
        }
        else {
            System.out.println("None of these");
        }
    }
}