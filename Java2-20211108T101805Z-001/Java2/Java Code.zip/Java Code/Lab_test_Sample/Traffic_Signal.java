
/**
 * Write a description of class five_java here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Traffic_Signal
{
   private int light;
   private final int GREEN=0;
   private final int YELLOW=1;
   private final int RED=2;
   private final int RARROW=3;
   public Traffic_Signal(){
       light=GREEN;
    }
    public int getLight(){
        return light;
    }
    public void changeLight(){
        switch(light){
            case GREEN :
                        light=YELLOW;
                        System.out.println("The light is YELLOW now");
                        break;
            case YELLOW:
                        light=RED;
                        System.out.println("The light is RED now");
                        break;
            case RED:
                        light=RARROW;
                        System.out.println("The light is RIGHT ARROW now");
                        break;
             case RARROW:
                        light=GREEN;
                        System.out.println("The light is GREEN now");
                        break;
            default : 
        }
    }
}