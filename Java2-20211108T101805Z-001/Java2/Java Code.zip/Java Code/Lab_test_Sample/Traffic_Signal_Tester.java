
/**
 * Write a description of class Traffic_Signal_tester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Traffic_Signal_Tester
{
    // instance variables - replace the example below with your own
    public static void main()
    {
        // initialise instance variables
         Traffic_Signal l1= new Traffic_Signal() ;
         
         for(int n=1;n<=4;n++){
         l1.changeLight();
        }
    }
}
