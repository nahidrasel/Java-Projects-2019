
import java.util.*;
public class three_java
{
   public static void main(){
       Scanner keyboard=new Scanner(System.in);
       System.out.println("how many number you want to input:??");
       int x=keyboard.nextInt();
       int min=x;
          while(keyboard.hasNextInt()){
                    x=keyboard.nextInt();
                    if(x<min)
                        min=x;
                    }
                
    System.out.println(min);
}
}
