
/**
 * Write a description of class One_java here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class One_java
{
    public static void main(){
        int mark=0;
        Scanner keyboard=new Scanner(System.in);
        System.out.println("Please Enter Your Mark(only numbers):");
        mark=keyboard.nextInt();
            if(mark<50){
                 System.out.println("Too-Bad");
            }
            else if(mark>70 && mark<=100){
                 System.out.println("Very Good");
            }
            else if((mark>=50 && mark<=70)){
                 System.out.println("So-So");
            }
            else 
            {
                 System.out.println("Wrong input");
                }
            }
        }
        