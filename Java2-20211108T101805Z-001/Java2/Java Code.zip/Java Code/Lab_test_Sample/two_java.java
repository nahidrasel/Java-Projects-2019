
import java.util.*;
public class two_java
{
   public static void main(){
       Scanner keyboard=new Scanner(System.in);
       int row,col;
       for(row=1;row<=5;row++){
           for(col=1;col<=5;col++){
               if(row >= col){
           System.out.print("*");
        }
        
    }
         System.out.println();
    }
}
}