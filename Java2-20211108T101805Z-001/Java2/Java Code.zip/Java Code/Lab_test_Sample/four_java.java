
/**
 * Write a description of class four_java here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class four_java
{
    public static void main(){
        Scanner keyboard = new Scanner(System.in);
        System.out.println("How many First number:");
        int n=keyboard.nextInt();
    
        double result=Math.pow((( n*(n +1))/2),2);

        System.out.println("The sum of the cubes of the first "+n+"natural numbers is "+ result);
}
}