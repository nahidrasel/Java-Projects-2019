
/**
 * This program will calculate the sum of the square of even numbers.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;

    public class four_java {
        
        public static void main(){
            
        //declare the variables
        
        Scanner keyboard = new Scanner(System.in);
        int result=0;
        int sum=0;
        
        //ask user to enter the value of n
        System.out.println("Enter the value of n:");
        int n=keyboard.nextInt();
        
        //conditon for sum of the square of even numbers
       if(n%2==0){
	for (int i = 1; i <= n; i++) {
	       sum=n*n;
	   }
}
	   System.out.print(sum);
	}
}