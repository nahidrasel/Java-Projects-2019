
/**
 * This programme will display height into different catagories.
 *
 * @author (Nahid Mahmud)
 * @version (100333)
 */
import java.util.*;
public class two_java
{
    public static void main(String[] args){ 
        
        //declare the variables
        int temperature;
        Scanner keyboard = new Scanner(System.in);
        
        //Asks user to input the temperature
        System.out.println("What is the temperature outside now ?");
        temperature=keyboard.nextInt();
        
        //Condition for recommended
        if(temperature>85){
            System.out.println("The recommended activity is Swimming");
        }
        else if(temperature>70 &&temperature <=85){
            System.out.println("The recommended activity is Tennis");
        }
        else if(temperature>32 && temperature <=70){
            System.out.println("The recommended activity is Golf");
        }
        else if(temperature>0 && temperature <=32){
            System.out.println("The recommended activity is Skiing");
        }
        else {
            System.out.println("Dancing");
        }
        System.out.println("****** THANK YOU ******");
        }
    }
        
        
   