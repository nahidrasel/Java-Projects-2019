
/**
 * This program will change the lightSignal to ON and OFF.
 *
 * @author (Nahid)
 * @version (100333)
 */
public class light_Signal
{
   //declare the variables
   
   private int light;
   private final int on=0;
   private final int off=1;
   
   //get and return the light signal
   
   public light_Signal(){
       light=on;
    }
    
    public int getLight(){
        return light;
    }
    
    //change the light signal using condition
    
    public void changeLight(){
        switch(light){
            case on :
                        light=off;
                        
                        //display the present signal of light
                        
                        System.out.println("The light is OFF now");
                        break;
            case off:
                        light=on;
                        System.out.println("The light is ON now");
                        break;
            default : 
        }
    }
}