
/**
 * Write a description of class Three_java here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Three_java {
    public static void main(){
        
        //declare the variables
        Scanner keyboard=new Scanner(System.in);
        int row,col;
        int n;
        
        //ask user tpo insert the number
        System.out.println("Enter the number :");
        n=keyboard.nextInt();
        
        //condition for display the @
        for(row=1;row<=n;row++){
           for(col=1;col<=n+1;col++){
               if(row != col){
                   
           //display the @        
           System.out.print("@");
        }
        
    }
         System.out.println();
    }
}
}