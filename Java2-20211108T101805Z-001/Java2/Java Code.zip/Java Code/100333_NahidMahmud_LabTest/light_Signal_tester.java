
/**
 *Test the lightSignal here.
 *
 * @author (Nahid)
 * @version (100333)
 */
import java.util.*;
public class light_Signal_tester
{
    public static void main()
    {
        // initialise instance variables
        light_Signal l1= new light_Signal() ;
         
        //using the loop 3 times for checking the appropriate output
         for(int n=1;n<=3;n++){
         l1.changeLight();
        }
    }
}
