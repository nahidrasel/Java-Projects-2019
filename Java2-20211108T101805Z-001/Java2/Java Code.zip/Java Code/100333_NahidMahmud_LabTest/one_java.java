
/**
 * This programme will display height into different catagories.
 *
 * @author (Nahid Mahmud)
 * @version (100333)
 */
import java.util.*;
public class one_java
{
    public static void main(String[] args){
        
        //declare the variables
        int height;
        Scanner keyboard = new Scanner(System.in);
        
        //Asks user to input the height in cm
        System.out.println("Please enter your height in centimetres:");
        height=keyboard.nextInt();
        
        //Given the Conditions
        if(height>=0 && height<150){
            //display the comment
            System.out.println("Your height is SHORT");
        }
        else if(height>=150 && height <=180){
            System.out.println("Your height is MODERATE");
        }
        else if(height>180){
            System.out.println("Your height is TALL");
        }
        else {
            System.out.println("WRONG HEIGHT");
        }
        System.out.println("****** THANK YOU ******");
        }
    }
        
        
   