
/**
 * this program will do the idetical here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class idetical
{
   public static void main(String[] args){
       String t1,t2;
       
       Scanner keyboard=new Scanner(System.in);
       System.out.println("Please Insert Your First Text:");
       t1=keyboard.nextLine();
       
       Scanner keyboard=new Scanner(System.in);
       System.out.println("Please Insert Your Second Text:");
       t2=keyboard.nextLine();
       
       identical=t1.equals.(t2);
       System.out.println(s1);
       
       notidentical=t1.notequals.(t2);
       System.out.println(s2);
       
       System.out.println("Please Insert Your First Text:");
    }
}