

/**
 * Write a description of class stringtest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class stringtest
{
    public static void main(String[] args)   {
        String we = "We";      
        String you = "You";      
        String overcome = "will overcome";      
        String phrase = we + overcome;
        System.out.println(phrase);      
        overcome = " " + overcome;
        System.out.println(phrase);      
        we = "Wii";      
        phrase = we + overcome;
        System.out.println(phrase);
        String phrase2 = phrase.replace('W','M'); 
        String phrase3 = phrase.replace('W','w'); 
        System.out.println(phrase2);   
        System.out.println(phrase3);
        booleansameString=phrase.equals(phrase2);
        System.out.println(sameString);
        sameString = phrase.equals(phrase3);
        System.out.println(sameString);
        sameString = phrase.equalsIgnoreCase(phrase3);
        System.out.println(sameString);
        int stringLength = phrase.length();
        System.out.println(stringLength);   }
    }
      