
/**
 * Write a description of class greetingofastring here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class greetingofastring
{
   public static void main(String[] args){
       String s;
       
       Scanner keyboard=new Scanner(System.in);
       
       System.out.println("Please Enter Your Name:");
       s=keyboard.nextLine();
       
       System.out.println("Hi "+s);
    }
}
