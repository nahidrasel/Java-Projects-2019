
/**
 * Write a description of class CIircle_find_radius_diameter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CIircle_find_radius_diameter
{
    private String name;
    private String lecturer;
    private int quota;
    private int currentEnrolment;
    public Subject(String subjectName,String lecturerName,int maxQuota){
       name=subjectName;
       lecturer=lecturerName;
       quota=maxQuota;
       currentEnrolment=0;
    }
    public void enrolStudent(){
        System.out.print("Enrolling student.. ");
        if(currentEnrolment<quota){
            ++currentEnrolment;
            System.out.println("Student enrolled in "+name);
        }
        else {System.out.println("Quota reached,enrolment failed");
        }
    }
    public void unEnrolStudent(){
        System.out.print("Un-enrolling student.. ");
        if(currentEnrolment<=0){
            System.out.println("No students to un-roll");
        }
        else {
            --currentEnrolment;
            System.out.println("Student un-enrolled from "+name);
        }
        }
        public void displaySubjectInfo(){   
            System.out.println("Subject name: " + name);   
            System.out.println("Lecturer: " + lecturer);   
            System.out.println("Quota: " + quota);   
            System.out.println("Currently enrolled: " +currentEnrolment);   
            int availablePlaces = quota-currentEnrolment;   
            System.out.println("Can accept " + availablePlaces + " more students");}
}
