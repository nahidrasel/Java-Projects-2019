
/**
 * Write a description of class Circle here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Circle
{
    // instance variables - replace the example below with your own
    private double radius;
    /**
     * Constructor for objects of class Circle
     */
    public Circle(double r)
    {
        // initialise instance variables
        if(r>0){
            radius = r;
    }
}
    /*
     * diameter () method calculte and display the diameter of circle
     **/ 
    public void diameter()
    {
        double circleDiameter = 2 * radius;
        System.out.println("The diameter is :"+circleDiameter);
    }
     /**
     * perimeter () method calculte and display the perimeter of circle
     **/ 
    public void perimeter()
    {
        double circlePerimeter = 2 * Math.PI*radius;
        System.out.println("The Perimeter is :"+circlePerimeter);
    }
     /**
     * area () method calculte and display the area of circle
     **/ 
    public void area()
    {
        double circleArea = Math.PI*radius * radius;
        System.out.println("The area is :"+circleArea);
    }

    public void displayAll(){
        System.out.println("The radius is :"+radius);
        this.diameter();
        this.perimeter();
        this.area();
    }
} //end of the class
