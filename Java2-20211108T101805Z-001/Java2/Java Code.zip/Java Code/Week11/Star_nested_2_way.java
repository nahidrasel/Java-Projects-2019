
/**
 * Write a description of class Star_nested_2_way here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Star_nested_2_way
{
   public static void main(){
       Scanner keyboard=new Scanner(System.in);
       int n;
       int row,col;
       n=keyboard.nextInt();
       for(row=1;row<=n;row++){
           for(col=1;col<=n;col++){
               if(row >= col){
           System.out.print("* ");
        }
        
    }
         System.out.println();
    }
}
}