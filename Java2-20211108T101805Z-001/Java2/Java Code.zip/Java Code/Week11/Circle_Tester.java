
/**
 * Write a description of class Circle_Tester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Circle_Tester
{
    // instance variables - replace the example below with your own
    public static void main()
    {
        // initialise instance variables
        Circle c1=new Circle(5.0);
        c1.displayAll();
        Circle c2= new Circle(-10);
        c2.displayAll();
    }  
}
