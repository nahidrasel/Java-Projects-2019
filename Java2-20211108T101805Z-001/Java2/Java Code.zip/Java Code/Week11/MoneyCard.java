
/**
 * Write a description of class MoneyCard here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class MoneyCard
{
    public static void main(String[] args) {
    private String cardNumber;   
    private String customerName;   
    private String currency;   
    private double balance;
public MoneyCard(StringcardNo,String custName,String currType){
     cardNumber = cardNo;
     customerName = custName;   
     currency = currType;   
     balance = 0;
}