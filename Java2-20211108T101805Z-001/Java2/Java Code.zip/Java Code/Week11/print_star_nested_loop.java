
/**
 * Write a description of class print_star_nested_loop here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class print_star_nested_loop
{
   public static void main(){
       Scanner keyboard=new Scanner(System.in);
       int n;
       int row,col;
       n=keyboard.nextInt();
       for(row=1;row<=n;row++){
           for(col=1;col<=row;col++){
           System.out.print("* ");
        }
         System.out.println();
    }
}
}