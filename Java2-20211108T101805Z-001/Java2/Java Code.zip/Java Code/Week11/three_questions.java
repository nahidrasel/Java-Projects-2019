
/**
 * Write a description of class three_questions here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class three_questions
{
    public static void main(String[] args)
    {
        int s=0;
        Scanner keyboard=new Scanner(System.in);
        
        System.out.println("What is the color of the sky:\n 1.Blue\t  2.Green\t  3.Red\t");
        int a=keyboard.nextInt();
        if(a==1){
         s++;
}
System.out.println("What is solid:\n 1.Water\t 2.Wood \t 3.Steel");
        int a1=keyboard.nextInt();
        if(a==3){
         s++;
}
System.out.println("What is the capital of nz:\n 1.auck\t 2.well\t 3.ham");
        int a3=keyboard.nextInt();
        if(a==2){
         s++;
}

System.out.println("Answer"+s);
}
}