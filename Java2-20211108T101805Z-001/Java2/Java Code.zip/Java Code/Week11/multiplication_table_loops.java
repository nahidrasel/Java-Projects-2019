
/**
 * Write a description of class multiplication_table_loops here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class multiplication_table_loops
{
    public static void main(){
       Scanner keyboard=new Scanner(System.in);
       int c;
       int a;
       int b;
       
       for(a=1;a<=9;a++){
           
           
           for(b=1;b<=10;b++)System.out.print("This is for multiplication table:"+b);{
               
               c=a*b;
         System.out.print(b+ "*" +a+ "="+c+ "\t");
        }
        System.out.println();
    }
}   
}