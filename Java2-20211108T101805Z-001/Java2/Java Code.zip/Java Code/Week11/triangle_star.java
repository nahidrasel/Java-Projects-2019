
/**
 * Write a description of class pyramids_star here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class triangle_star
{
   public static void main(){
       Scanner keyboard=new Scanner(System.in);
       int n;
       int row,col;
       n=keyboard.nextInt();
       for(row=1;row<=n;row++){
           int spaces=n-row;
           int stars=row*2-1;
           
           for(col=1;col<=spaces;col++){
               
           System.out.print("  ");
        }
        for(col=1;col<=stars;col++){
            System.out.print("* ");
            
    }
         System.out.println( );
    }
}
}