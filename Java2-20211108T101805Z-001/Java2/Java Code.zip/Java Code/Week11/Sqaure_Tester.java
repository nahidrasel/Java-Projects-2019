
/**
 * Write a description of class Sqaure_Tester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Sqaure_Tester
{
    // instance variables - replace the example below with your own
    public static void main()
    {
        // initialise instance variables
        Square c1=new Square(5.0);
        c1.display();
        Square c2= new Square(-10);
        c2.display();
    }  
}
