
/**
 * Write a description of class Square here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Square
{
    // instance variables - replace the example below with your own
    private double length;
    /**
     * Constructor for objects of class Square
     */
    public Square(double l)
    {
        // initialise instance variables
        if(l>0){
            length = l;
        }
    }
        public void area()
    {
        double squareArea=length*length;
        System.out.println("The area is :"+squareArea);
    }
  
    public void display(){
        System.out.println("The length is :"+length);
        this.area();
    }
} //end of the class
