
/**
 * Write a description of class Point_Tester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Point_Tester
{
    // instance variables - replace the example below with your own
    public static void main()
    {
        // initialise instance variables
        Point p1=new Point(5,5);
        Point p2=new Point(1,4);
        int x1=p1.getX();
        int y1=p1.getY();
        int x2=p2.getX();
        int y2=p2.getY();
        double d=Math.sqrt(Math.pow(x2-x1,2)+Math.pow(y2-y1,2));
        System.out.println("The distance between"+p1+"and"+p2+"is"+d);
    }  
}
