
/**
 * Write a description of class SubjectTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SubjectTester
{  
        public static void main(String[] args)   {      
            // Test 1: Create a subject and display the subject     
        Subject physics = new Subject("Physics Principles",
                                      "Dr Who", 100);      
        physics.displaySubjectInfo(); 
    physics.enrolStudent();
    physics.displaySubjectInfo();
   physics.unEnrolStudent();
   physics.unEnrolStudent();
   physics.displaySubjectInfo();
    }
        
    }