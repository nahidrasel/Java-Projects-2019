
/**
 * Write a description of class Point here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Point
{
    // instance variables - replace the example below with your own
    private int x;
    private int y;

    /**
     * Constructor for objects of class Point
     */
    public Point(int newX,int newY){
        x=newX;
        y=newY;
    }
    public void setX(int newX){
        
        // initialise instance variables
        x = newX;
    }
    public int getX(){
        return x;
    }
    public void setY(int newY){
        
        // initialise instance variables
        y = newY;
    }
    public int getY(){
        return y;
    }
    public String toString(){
        String point="";
        point="("+x+","+y+")";
        return point;
    }
}
