
/**
 * Write a description of class harmonic_series here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class harmonic_series
{
    public static void main(){
        double n=1,sum=1.0,total=0;
        System.out.println("Enter the value of n:");
        Scanner keyboard=new Scanner(System.in);
        n=keyboard.nextInt();
            while(sum<=n){
                   sum=sum/n;
                   total=total+sum;
                    n++;
                    }
System.out.println(sum);
}
}