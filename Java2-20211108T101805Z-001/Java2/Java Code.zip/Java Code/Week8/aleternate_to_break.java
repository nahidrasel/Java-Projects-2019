
/**
 * Write a description of class aleternate_to_break here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class aleternate_to_break
{
    public static void main(){
    int counter=0;
    int sum=0;
    int answer=0;

    Scanner keyboard = new Scanner(System.in);
    System.out.println("Enter numbers (q to quit)");
    do{
        numEntered = keyboard.hasNextInt();
        if(numEntered)
        {
            sum+=keyboard.nextInt();
        }
    }
    while(numEntered);
    System.out.println("The total is "+sum);
}
}