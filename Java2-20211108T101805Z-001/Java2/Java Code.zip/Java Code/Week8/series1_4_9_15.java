
/**
 * Write a description of class series1_4_9_15 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class series1_4_9_15
{
    public static void main(){
        int c=1,sum=0,total=1;
        {
            while(c<=10){
                    sum = sum + (int)Math.pow(c,2);
                    c++;
                }
    }
    System.out.println("The result is: "+sum);
}
}
            