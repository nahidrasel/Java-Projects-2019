
/**
 * Write a description of class pdct1to15_2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class pdct1to15_2
{
    public static void main(){
        int c=1,product=1;
        {
            while(c<=15){
                    product=product*c;
                    c+=2;
                }
        c++;
    }
    System.out.println("The result is: "+product);
}
}
            