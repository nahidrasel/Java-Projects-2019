
/**
 * Write a description of class printtablesof1_10_100_1000 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class printtablesof1_10_100_1000
{
    public static void main(){
  
        int x=1,result,result2,result3;
  
  System.out.println("x" + "\t"+ "10*x"+"\t" + "100*x"+"\t" + "1000*x"+"\t"  );
  
  while(x<=5){
      result=x*10;
      result2=x*100;
      result3=x*1000;

      System.out.println(x + "\t"+ result+"\t" + result2 +"\t" + result3+"\t"  );

      x++;
    }
}
}
/* or 
 * while(n<=5){
 *     System.out.println(N+"\t"+n*10+"\t"+n*100+"\t"+n*1000+"\t");
 *     n++;
 *  }
    */ 