
/**
 * Write a description of class indefiniteloop here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class indefiniteloop
{
   
     public static void main(){
         int x=10;
         while(x>0){
             System.out.println (x);
             x=x*1;
            }
            
}
}