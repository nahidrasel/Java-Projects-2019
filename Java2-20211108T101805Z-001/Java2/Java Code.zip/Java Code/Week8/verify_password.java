
/**
 * Write a description of class verify_password here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class verify_password
{
     public static void main(){
         String password="ICL123";
         int tries=0;
         boolean guessed=false;
         
         Scanner keyboard= new Scanner (System.in);
         while(tries<4 && !guessed){
             System.out.println("Enter the password:");
             String guess=keyboard.nextLine();
             if(guess.equals(password)){
                 System.out.println("Password verrified");
                 guessed=true;
                }
                else {
                    System.out.println("Invalid password");
                }
                ++tries;
            }
            
}
}