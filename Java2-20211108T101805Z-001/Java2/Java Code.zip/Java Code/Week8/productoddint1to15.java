
/**
 * Write a description of class productoddint1to15 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class productoddint1to15
{
    public static void main(){
        int x=1,total=1;
        {
            while(x<=15){
                if(x%2==1){
                    total=total*x;
                }
        x++;
    }
    System.out.println(total);
}
}
}
            