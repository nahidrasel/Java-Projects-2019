
/**
 * Write a description of class whileloop here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class whileloop
{
    public static void main(){
        int n=1;
        while(n<=10){
            System.out.println(n);
            ++n;
        }
    }
}