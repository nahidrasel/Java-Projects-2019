
/**
 * Write a description of class compound_interest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class compound_interest
{
    public static void main(){
    double initialBalance=10000;
    final double RATE=0.05;
    final int YEARS=20;
    double balance = initialBalance;
    for(int year = 1; year<=YEARS;year++){
        double interest=balance* RATE;
        balance= balance+interest;
        System.out.println("Interest for every year "+interest);
    }
    System.out.println("Balance after 20years is "+balance);
}
}