
/**
 * Write a description of class whileexcerise here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class whileexcerise
{
    public static void main(String[] args){
        int x=0;
        while(x<20){
            System.out.println(x);
            x=x+5;
        }
    }
}