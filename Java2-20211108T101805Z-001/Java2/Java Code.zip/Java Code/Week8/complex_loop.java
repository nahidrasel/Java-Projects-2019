
/**
 * Write a description of class complex_loop here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class complex_loop
{ public static void main(){
    int sum=0;
    boolean numEntered;
    Scanner keyboard = new Scanner(System.in);
    System.out.println("Enter numbers (q to quit)");
    do{
        numEntered = keyboard.hasNextInt();
        if(numEntered)
        {
            sum+=keyboard.nextInt();
        }
    }
    while(numEntered);
    System.out.println("The total is "+sum);
}
}