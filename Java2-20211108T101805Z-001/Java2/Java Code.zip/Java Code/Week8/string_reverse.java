
/**
 * Write a description of class string_reverse here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class string_reverse
{
   public static void main(String[] args){
    String text,reverse,i;
    Scanner keyboard = new Scanner(System.in);
    System.out.println("Enter the text:");
    text=keyboard.nextLine();
    for(i=i=stringlength.text()-1;i=--){
        System.out.println(text);
}
}
}
    
    
    
   