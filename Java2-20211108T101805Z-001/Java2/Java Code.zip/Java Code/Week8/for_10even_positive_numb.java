
/**
 * Write a description of class for_10even_positive_numb here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class for_10even_positive_numb
{ public static void main(){
    for(int x=2; x<=20;x=x+2){
    System.out.println(x);
}
}
}