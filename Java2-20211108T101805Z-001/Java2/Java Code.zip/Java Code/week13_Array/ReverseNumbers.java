
/**
 * Write a description of class ReverseNumbers here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class ReverseNumbers
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);
        int[] numbers=new int[10];
        System.out.println("Enter 10 integers:");
        for(int i=0; i<10;i++){
            numbers[i]=keyboard.nextInt();
        }
        System.out.println("In reverse order: ");
        for(int i=9;i>=0;i--){
            System.out.print(numbers[i]+" " );
        }
        System.out.println();
    }
}