
/**
 * Write a description of class sum_of_all_array_element here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class sum_of_all_array_element
{
    public static void main(String [] args){
        int sum=0;
        Scanner keyboard=new Scanner(System.in);
        
        int[] numbers = {0,1,2,3,4,5,6,7,8,9};
        int length=numbers.length;
             
           for(int i=0;i<length;i++){
               sum=numbers[i]+sum;
            }
            System.out.println("Sum is :"+sum);
        double average = (double) sum/length;
        System.out.println("Average is "+average);
    }
}
        