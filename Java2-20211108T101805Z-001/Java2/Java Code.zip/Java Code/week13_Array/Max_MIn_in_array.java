
/**
 * Write a description of class Max_MIn_in_array here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class Max_MIn_in_array
{
    public static void main(){
        int [] num={1,2,3,4};
        int i;
        int min=num[0],max=num[0];
        for(i=0;i<num.length;i++){
            if(num[i]<min){
                min=num[i];
            }
            else {
                max=num[i];
            }
        }
        
        System.out.println("Minimum is "+min);
        System.out.println("Max is "+max);
        }
    }