
/**
 * Write a description of class add_2_array here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class add_2_array
{
    public static void main(String [] args){
        int sum=0;
        Scanner keyboard=new Scanner(System.in);
        
        int[] number1 = {0,1,2,3,4};
        int[] number2= {5,6,7,8,9};
        int [] number3;
        int length1=number1.length;
        int length2=number2.length;
        int length=length1+length2;
        
             
           for(int i=0;i<length;i++){
               number3=number1[i]+ number2[i];
            }
            System.out.println("Sum is :"+sum);
        double average = (double) sum/length;
    }
}
        