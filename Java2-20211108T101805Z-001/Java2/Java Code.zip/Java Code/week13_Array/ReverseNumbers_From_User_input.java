
/**
 * Write a description of class CopyOfReverseNumbers here.
 *
 * @author (your name)
 * @version (20/05/19)
 */
import java.util.*;
public class ReverseNumbers_From_User_input

{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Enter 10 integers: ");
        int size=keyboard.nextInt();
        int[] numbers=new int[size];
        for(int i=0; i<size;i++){
            numbers[i] = keyboard.nextInt();
        }
        System.out.println("In reverse order: ");
        for(int i=size-1;i>=0;i--){
            System.out.print(numbers[i] +" " );
        }
        System.out.println();
    }
}
