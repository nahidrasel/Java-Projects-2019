
/**
 * Write a description of class Sum_of_odd_in_array here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Sum_of_odd_in_array
{
    public static void main(){
        int [] num={1,2,3,4};
        int sum=0,i;
        for(i=0;i<num.length;i++){
            if(num[i]%2!=0){
            sum=num[i]+sum;
        }
    }
        
             System.out.println(sum);
    }
}
