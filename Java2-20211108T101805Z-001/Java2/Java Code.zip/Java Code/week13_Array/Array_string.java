
/**
 * Write a description of class Array_string here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Array_string
{
    public static void main(String [] args){
        Scanner keyboard=new Scanner(System.in);
        
        String[] letters = {"i","c","l"};
        
        System.out.println("Please Enter A Letter: ");
        String letter=keyboard.nextLine();
             
        
           int length=letters.length;
           for(i=0;i<letter.length;i++){
               if(letter>letters[i]){
                }
            else {
                System.out.println("Does not string");
            }
        
        }
    }
}   