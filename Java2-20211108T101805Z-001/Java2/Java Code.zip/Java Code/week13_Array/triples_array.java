import java.util.*;
public class triples_array
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Enter size: ");
        int size=keyboard.nextInt();
        int[] numbers=new int[size];
        for(int i=0; i<size;i++){
            System.out.println("Enter integers: ");
            numbers[i] = keyboard.nextInt();
        }
        
        System.out.println("In triples order: ");
        for(int i=0;i<size;i++){
            System.out.print(numbers[i]*3 +" " );
        }
        System.out.println();
    }
}
