
/**
 * Write a description of class CopyOfpositive_neg_zero_in_array here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class CopyOfpositive_neg_zero_in_array
{
    public static void main(String [] args){
        int sum=0;
        int count=0;
        int positive=0,neg=0,zero=0;
        Scanner keyboard=new Scanner(System.in);
        
        int[] numbers = {-5,-1,0,1,-2,4,5};
             int length=numbers.length;
        for(int i=0;i<length;i++){
           if(numbers[i]>0){
               positive++;
            }
  
            else if(numbers[i]<0){
               neg++;
              
            }
            else {
                zero++;
            }
        }
         System.out.println("positives are total ="+positive);
         System.out.println("negs are total ="+neg);
         System.out.println("zeros are total ="+zero);
    }
}       
