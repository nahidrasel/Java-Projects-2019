
/**
 * Write a description of class Method2OfMax_MIn_in_array here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Method2OfMax_MIn_in_array
{
    public static void main(){
        int [] numbers={1,2,3,4};
        int min=numbers[0];
        int max=numbers[0];
        
        for(int i=1;i<numbers.length;i++){
            if(min>numbers[i])
                min=numbers[i];
           
            if( max<numbers[i])
                max=numbers[i];
            }
            System.out.println("The minimum number is "+min);
            System.out.println("The maximum number is "+max);
        }
    }
