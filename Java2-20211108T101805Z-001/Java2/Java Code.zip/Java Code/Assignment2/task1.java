
/**
 * This program will calculate the commission on sale here.
 * @author (Nahid Mahmud)
 * @version (100333)
 */
import java.util.*;
public class task1
{
    public static void main(String[] args){
        
        //declare the variables 
        double salary=300,totalCommission=0;
        double quantity=0,laptop=0,harddisk=0,smartphone=0;
        char operation;
        int price=0;
        
        Scanner keyboard=new Scanner(System.in);
        
        //use the do-while loop
        
        do {
            System.out.println("Please select an item ,Press an Alphabet from the list"); 
            System.out.println("1.L for Laptop\n 2.S for Smartphone\n 3.H for Hard Disk 4.E for Exit");
            operation=keyboard.next().charAt(0);
        
            //use switch inside the do-while loop  
        
        switch(operation){
              case 'L':
              case 'l':
                     System.out.println("The price of Laptop is:");
                     price=keyboard.nextInt();
                     
                     System.out.println("How many laptops did you sell:");
                     quantity=keyboard.nextInt();
                     //calculte the quantity & price 
                     laptop=(quantity*price)*0.10;
                     
                     System.out.println("You sell total " +quantity+ "  laptop");
                     System.out.println("Your commission is  :" +laptop);
                     System.out.println("Thank you! The operation has been saved! ");
                     
                     break;
          
             case'S':
             case's':
                    System.out.println("The price of Smartphone is:");
                    price=keyboard.nextInt();
                    
                    System.out.println("How many Smartphones did you sell:");
                    quantity=keyboard.nextInt();
                    //calculte the quantity & price 
                    smartphone=(quantity*price)*0.10;
                    System.out.println("You sell total " +quantity+ "  smartphone");
                    System.out.println("Your commission is  :" +smartphone);
                    System.out.println("Thank you! The operation has been saved! ");
                    
                    break;
            
            case 'H':
            case 'h':
        
                    System.out.println("The price of Harddisk is:");
                    price=keyboard.nextInt();
                    
                    System.out.println("How many Harddisks did you sell:");
                    quantity=keyboard.nextInt();
                    //calculte the quantity & price 
                    harddisk=(quantity*price)*0.10;
                    System.out.println("You sell total " +quantity+ "  harddisk");
                    System.out.println("Your commission is  :" +harddisk);
                    System.out.println("Thank you! The operation has been saved! ");
                    
                    break;
                
           case 'E':
           case 'e':
                    // calculate the total commission of items
                    
                    totalCommission=laptop+harddisk+smartphone;
                   
                    //display the total commission
                    
                    System.out.println("Your total commission is 10% of total sale.\nwhich is:"+totalCommission);
                    
                    //display& calculate the total salary
                    salary=totalCommission+300;
                    
                    System.out.println("Your total salary is:"+salary);
                    break;
           default:
                   System.out.println("Wrong input");
                   }
                }
                
                //Set the condition for exit the loop
                while(operation!='E' &&  operation!='e');
            }
        }