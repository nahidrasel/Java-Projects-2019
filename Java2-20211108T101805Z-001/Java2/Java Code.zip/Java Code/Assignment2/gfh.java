
/**
 * Write a description of class gfh here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class gfh
{
 
    public static void main(String [] args) {
        double num1,num2,sum;
        char op;
        char ch=5;
        double addition=0,multiplication=0,division=0,subtraction=0;
 
        Scanner input = new Scanner(System.in);
        do{
         
        System.out.print("Enter your num: ");
        num1 = input.nextDouble();
        
        System.out.print("Enter your op: + for, - for , * for , / for  ");
        op = input.next().charAt(0);
        
        System.out.print("Enter your number: ");
        num2 = input.nextDouble();
         
       switch (op){
           case '+' :
          addition=num1 + num2;
            
           break;
           case '-':
           subtraction=num1 - num2;
           System.out.println(subtraction);
        case '*':
          multiplication=num1 * num2;
            System.out.println(multiplication);
            break;
        case '/':
        division=num1 / num2;
             
           System.out.println(division);
           break;
        case '=':
         double result=addition+subtraction+division+multiplication;
         break;
        default:
           System.out.println("Not a valid option");
            }
    }
        while(ch!='=');
}
}
