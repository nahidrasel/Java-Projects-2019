/**
 * This program will calculte the operations of numbers.
 *
 * @author (Nahid Mahmud)
 * @version (100333)
 */
import java.util.*;
public class task2
{
   public static void main(String[] args)
    {
        //Declare the variables 
        
        double num1;
        char choose;
        double result = 0.0, temp = result, oldResult = result,finalResult;
        Scanner keyboard= new Scanner(System.in);
        
        //Use switch,loop and conditions
        do {
            System.out.println("Enter number:");
            num1 = keyboard.nextDouble();
            System.out.println("Enter your selection: '+' for Addition,'-' for substraction '*' for Multiplication and '/' for division");
        System.out.println("Press '=' for Total Result & Exit");
            choose = keyboard.next().charAt(0);
       
        switch (choose){
   
           case '+': 
                    temp=num1;
                    oldResult=result;
                    result = result + temp;
                      break;
           case '-':
                 temp=num1;
                 oldResult=result+num1;
                 result = result - temp;
                      break;
                   
           case '*': 
                    temp=num1;
                    oldResult=result+num1;
                    result = result * temp;
                     break;
           case '/':
                    temp=num1;
                    oldResult=result+num1;
                    result = result / temp;
                      break;
            case '=':                     
                      finalResult=result+num1;
                      
                      //Display the final result
                      System.out.println("Final Result:" +finalResult); 
                      break;
            default:
                      System.out.println("Illigal Operation");
            }
        }
            
            while(choose!='=');
        }
    }