
/**
 * This program will calculate the commission on sale here.
 * @author (Nahid Mahmud)
 * @version (a version number or a date)
 */
import java.util.*;
public class ADD_3
{
    public static void main(String[] args){
        double salary=300;
        boolean error=false;
        int quan,q1=0,q2=0,q3=0;
        char ch;
        double commission;
        double gsP;
        double add=0;
        Scanner keyboard=new Scanner(System.in);
        
        do {
        System.out.println("Please select an item ,Press an Alphabet from the list"); 
        System.out.println("1.L for Laptop\n 2.S for Smartphone\n 3.H for Hard Disk 4.E for Exit");
        ch=keyboard.next().charAt(0);
        switch(ch){ 
    
                    case 'L':
                    case 'l':
                        System.out.println("The price of Laptop is:1500");
                        System.out.println("How many Laptop did you sell");
                        quan=keyboard.nextInt();
                        q1=quan;
                        
                        break;
          
                    case'S':
                    case's':
                System.out.println("The price of Smartphone is:1000");
                System.out.println("How many Smartphone did you sell");
                quan=keyboard.nextInt();
                q2=quan;
                
                break;
          case 'H':
          case 'h':
        
                System.out.println("The price of Harddisk is: 500");
                System.out.println("How many Laptop did you sell");
                quan=keyboard.nextInt();
                q3=quan;
                break;
 
          
                    
         case '=':
         add=q1+q2+q3+300;
        System.out.println(add);
        break;
        
        default:
        System.out.println("Wrong input"); 
         }
        }
        while(ch!='=');
        
}
}
