
/**
 *This program will play the guessing game.
 *
 * @author (Nahid Mahmud)
 * @version (09/05/19)
 */
import java.util.Random;
import java.util.*;
public class task3

{
 public static void main(String[] args) {
     
    //Declare the variables
    Random randomNumber = new Random();
    Scanner keyboard = new Scanner(System.in);
    int computerValue;
    int numberOfTries = 0;
    int success = 0;
    int guess;
    boolean playAgain;
    
    //Logic and While Loop for doing the operation again and again
    do {
        computerValue = randomNumber.nextInt(100);
        guess = 0;
        playAgain = false;
        while (guess != computerValue) {
            
            System.out.println("Please enter an integer betwen 1 and 100 : ");
            guess = keyboard.nextInt();
            numberOfTries++;
            
            if (guess < 1 || guess > 100) {
                System.out.println("Invalid input");
            } else if (guess < computerValue) {
                System.out.println("Your guess is too low!");
            } else if (guess > computerValue) {
                System.out.println("Your guess is too high!");
            }
        }
        success++;
        
        //display the tries and correct answer of guessing value 
        
        System.out.println("Congratulations you won! Your numbers of tries was: " + numberOfTries + " and the number was: " + computerValue);
        System.out.println("Would you like to play again? Only press y or Y \n Else Press Any Key to Exit");
        switch (keyboard.next()) {
            case "y":
            case "Y":
                playAgain = true;
                break;
            default:
                break;
        }
    }
    //again while loop for play again and again
    while (playAgain);
    System.out.println("Goodbye");
}
}