;
/**
 * This program will calculate the commission on sale here.
 * @author (Nahid Mahmud)
 * @version (a version number or a date)
 */
import java.util.*;
public class ADD_MUL_SUB
{
    public static double total;
    public static void main(String[] args){
        int a,b;
        char op;
        double sub;
        double mul;
        double div;
        Scanner keyboard=new Scanner(System.in);
        do{
            
            System.out.println("Please enter number:"); 
            a=keyboard.nextInt();
        
            switch ch{
                
                System.out.println("Press an number from the list :\n 1.+ add\n 2.- sub\n 3.* mul\n 4./div &&  5. = for total");
            char operation=keyboard.nextLine().charAt(0);
        while(ch!='=');
        
    }
}
    /*simple calculator .
    .
    ans = 5+6*3=33
    no precendence;
    while(input!=5);
    /*do{
           if(input==1){
           total=a+b;
        }
        else if(input==2){
            total=a-b;
        }
        else if(input==3){
            total=a*b;
        }
        else if(input==4){
            total=a/b;
        }
        System.out.println("Result is:"+total);
        */
    /*
}
}
        
        
 while and switch ; that's all
 */