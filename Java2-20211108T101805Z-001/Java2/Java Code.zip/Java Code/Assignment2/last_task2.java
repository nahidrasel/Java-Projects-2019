
/**
 * Write a description of class last_task2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.util.*;
public class last_task2 {
    
    public static void main (String [] args){

        double result = 0.0, temp = result, oldResult = result;
 
		Scanner input = new Scanner(System.in);
 
		//Initialization of Calculator
		System.out.println("Calculator is on");
		System.out.println("result = " + result);
 
		//Calculations
		String operation = "";
		while (!operation.equals("R") && !operation.equals("r")) {
			operation = input.nextLine();
 
			//Read operator
			char sign = operation.charAt(0);
 
			//Addition, Subtraction, Multiplication, Division
			switch (sign){
			case '+': temp = Double.parseDouble(operation.substring(1));
					  oldResult = result;
					  result = result + temp;
					  System.out.println(oldResult + " + " + temp + " = " + result);
					  break;
			case '-': temp = Double.parseDouble(operation.substring(1));
					  oldResult = result;
					  result = result - temp;
					  System.out.println(oldResult + " - " + temp + " = " + result);
			  		  break;
			case '*': temp = Double.parseDouble(operation.substring(1));
					  oldResult = result;
					  result = result * temp;
					  System.out.println(oldResult + " * " + temp + " = " + result);
					  break;
			case '/': temp = Double.parseDouble(operation.substring(1));
					  oldResult = result;
					  result = result / temp;
					  System.out.println(oldResult + " / " + temp + " = " + result);
	  		          break;
			case 'r': break;
			case 'R': break;
			default: System.out.println(sign + " is an unknown operation");
					 System.out.println("Reenter your last line: ");
 
			}
 
			//END
		}	
 
 
		//Printing of Result
		System.out.println("Final result = " + result);
 
		//Again Method
		System.out.println("Again?");
		String again = input.nextLine();
 
 
		}
 
 
}