
/**
 * Write a description of class ShowAge here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.util.*;
public class ShowAge
{
    public static void main(String[] args)
    {
        int age;
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter a age:");
        age=keyboard.nextInt();
        
        System.out.println("Your Age is "+ age);
    }
}
