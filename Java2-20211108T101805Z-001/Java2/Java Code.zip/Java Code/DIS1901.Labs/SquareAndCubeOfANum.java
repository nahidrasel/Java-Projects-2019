
/**
 * Write a description of class SquareAndCubeOfANum here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class SquareAndCubeOfANum
{
    public static void main(String[] args)
    {
        int x,cube,square;
        
        Scanner keyboard = new Scanner(System.in);
                   
        System.out.print("Enter a number:");
        x=keyboard.nextInt();
        cube=x*x*x;
        square=x*x;
        
        
        System.out.println(square & cube );
    }
}
