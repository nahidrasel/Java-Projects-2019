
/*
 * Write a description of class qsn12inweek3l2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class qsn12inweek3l2
{
    public static void main(){
        //this programe will product the result of three integers.
        /*tjsd,gndnhdh
      dfshgdsfhf
         */
        int c, thisIsAVariable,q76354,number; 
        Scanner keyboard = new Scanner(System.in);
        
        System.out.print("Please input an integer"); 
        
        int value = keyboard.nextInt();
        
        System.out.println("This is a Java program");
        System.out.println("This is a Java ");
        System.out.println("program");
        System.out.print("This is a Java ");
        System.out.print("program");
    }
}
