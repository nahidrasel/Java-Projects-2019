
/**
 * Write a description of class Tablefrclsparty here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Tablefrclsparty
{
    public static void main(String[] args)   {
        // Get number of guests      
        Scanner keyboard = new Scanner(System.in);      
        System.out.print("Please enter the number of guests: ");      
        int numberOfGuests = keyboard.nextInt();      
        // Get number of seats per table      
        System.out.print("Enter the number of seats per table: ");      
        int tableSize = keyboard.nextInt();      
        // Calculate number of tables needed      
        int numberOfTables =(int)Math.ceil((double)numberOfGuests / tableSize);      
        // Output number of tables    
        System.out.println("Then you will need " + numberOfTables+ " tables.");
    }
}
