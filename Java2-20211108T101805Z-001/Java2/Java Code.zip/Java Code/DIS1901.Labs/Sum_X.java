
/**
 * Write a description of class Sum_X here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Sum_X
{
    public static void main(String[] args){
    int x,sum;
    x = 1;
    sum = 0;
    sum = x + sum;
    System.out.print("The sum is: ");
    System.out.println(sum);

}
}