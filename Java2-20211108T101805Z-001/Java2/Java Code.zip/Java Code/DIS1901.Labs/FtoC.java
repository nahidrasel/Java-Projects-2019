
/**
 * Write a description of class FtoC here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class FtoC
{
    public static void main(String[] args)
   {
       double tempInCelsius;
       double tempInFarenheit;
       Scanner keyboard =new Scanner(System.in);
       System.out.print("Enter a temperature in Farenheit: ");
       tempInFarenheit = keyboard.nextDouble();
       //calculate the Farenheit equivalent 
       tempInCelsius=(tempInFarenheit-32)*5/9;
       System.out.println(tempInFarenheit+
       "Farenheit is equivalent to"+tempInCelsius);
    }
}
