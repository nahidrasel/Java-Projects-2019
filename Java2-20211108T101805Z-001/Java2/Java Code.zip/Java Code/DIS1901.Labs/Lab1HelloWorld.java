
/**
 * Write a description of class Lab1HelloWorld here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Lab1HelloWorld
{
    public static void main(){
        System.out.print("Hello World!");
         
    }
}
