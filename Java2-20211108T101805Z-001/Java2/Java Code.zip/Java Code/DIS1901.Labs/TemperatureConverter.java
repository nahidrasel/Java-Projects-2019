
/**
 * Write a description of class TemperatureConverter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class TemperatureConverter
{
   public static void main(String[] args)
   {
       double tempInCelsius;
       double tempInFarenheit;
       Scanner keyboard =new Scanner(System.in);
       System.out.print("Enter a temperature in Celsius: ");
       tempInCelsius = keyboard.nextDouble();
       //calculate the Farenheit equivalent 
       tempInFarenheit=(tempInCelsius*9)/5+32;
       System.out.println(tempInCelsius+"Celsius is equivalent to"+tempInFarenheit);
    }
}
