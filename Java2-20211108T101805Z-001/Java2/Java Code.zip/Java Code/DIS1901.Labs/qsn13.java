
/**
 * This program will calculate the product of three integers.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class qsn13
{
    public static void main(String[] args){
        Scanner keyboard = new Scanner(System.in);
        int x ,y,z, result;
        System.out.print("Input first number: ");
        x = keyboard.nextInt();
  System.out.print("Input second number: ");
  y = keyboard.nextInt();
   System.out.print("Input third number: ");
   z= keyboard.nextInt();
   result=x*y*z;
  System.out.println("Product is :"+result);
 }
}