
/**
 * Write a description of class Findevenorodd here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Findevenorodd
{
    public static void main(){
        int num;
        
        Scanner keyboard=new Scanner(System.in);
        System.out.println("Enter an Integer:");
        num=keyboard.nextInt();
        
        if(num%2==0){
            System.out.println("Even");
        }
        else {
            System.out.println("odd");
        
       }
    }
}        
        
        
    