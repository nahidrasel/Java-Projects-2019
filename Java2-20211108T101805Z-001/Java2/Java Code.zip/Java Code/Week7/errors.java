
/**
 * Write a description of class errors here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class errors
{
    public static void main(){
    
      int x,y;
    Scanner keyboard=new Scanner(System.in);
    y=keyboard.nextInt();
    x=keyboard.nextInt();
      if ( y == 8 )
    if ( x == 5 )
    System.out.println("@@@@@");
    else
    {
    System.out.println( "#####" );
    System.out.println( "$$$$$" );
    System.out.println( "&&&&&" );
}
}
}