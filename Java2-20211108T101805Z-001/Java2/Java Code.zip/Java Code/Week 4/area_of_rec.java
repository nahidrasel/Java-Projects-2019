
/**
 * Write a description of class area_of_rec here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class area_of_rec
{
    public static void main(String[] args){
        
       //declare the area of rectangle
       int length,width,rectangle;
       
       //Get the length & width
        Scanner keyboard=new Scanner(System.in);
        
        System.out.println("Enter length of rectangle:");
        length=keyboard.nextInt();
        
        System.out.println("Enter Width of rectangle:");
        width=keyboard.nextInt();
        
      //Calculate the area of rectangle
        rectangle=(length*width);
        
        //Output the result
        System.out.println("The area of rectangle is:"+rectangle);
    }
}