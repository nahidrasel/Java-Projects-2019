
/**
 * This programme will calculate the addition of two numbers.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Add_two_num
{
    public static void main(String[] args){
        //Declare the two numbers & result
        int a;
        int b;
        int result;
        
        //Get the two numbers
        Scanner keyboard=new Scanner(System.in);
        System.out.println("Enter First Integer:");
        a=keyboard.nextInt();
        System.out.println("Enter Second Integer:");
        b=keyboard.nextInt();
        
        //Calculte the addition of two integer
        result= a+b;
        
        //output the result
        System.out.println("The addition of two Integer is:"+result);
    }
}