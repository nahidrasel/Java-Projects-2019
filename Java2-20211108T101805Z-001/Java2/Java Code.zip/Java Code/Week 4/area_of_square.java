
/**
 * Write a description of class area_of_square here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class area_of_square
{
    public static void main(String[] args){
       //declare the length of square & area
       int length,area;
       
       //Get the length
        Scanner keyboard=new Scanner(System.in);
        System.out.println("Enter length of side:");
        length=keyboard.nextInt();
        
      //Calculate the area of square
        area=length*length;
        
        //Output the result
        System.out.println("The area of square is:"+area);
    }
}