
/**
 * Write a description of class three_marks here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class three_marks
{
    public static void main(String[] args){
    //Declare the three marks,average & result
        int num1;
        int num2;
        int num3;
        double avg;
        double result;
        
        //Get the three numbers
        Scanner keyboard=new Scanner(System.in);
        System.out.println("Enter First marks:");
        num1=keyboard.nextInt();
        System.out.println("Enter Second marks:");
        num2=keyboard.nextInt();
        System.out.println("Enter Third marks:");
        num3=keyboard.nextInt();
        
        //Calculate the addition of marks
        result= num1+num2+num3;
        
        //calculate the average of marks
        avg=result/3;
 
        //output the result
        System.out.println("The average of marks is:"+avg);
    }
}
