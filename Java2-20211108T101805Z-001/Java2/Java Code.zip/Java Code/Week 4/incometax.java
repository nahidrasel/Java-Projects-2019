
/**
 * Write a description of class incometac here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class incometax
{
    public static void main(String[] args){
        
        //Declare the variables
        double income;
        double incometax;
        
        //Get the early income
        Scanner keyboard=new Scanner(System.in);
        System.out.println("Enter your income:");
        income=keyboard.nextInt();
        
        //Calculte the incoem tax
        incometax= (income*16)/100;
        
        //output the result
        System.out.println("The income tax is:"+incometax);
    }
}