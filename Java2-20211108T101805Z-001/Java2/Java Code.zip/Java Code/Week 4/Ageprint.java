
/**
 * Write a description of class Ageprint here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Ageprint {
    public static void main(String[] args){
    //Declare the Variables
    double age;
    
    //Enter age
    Scanner keyboard=new Scanner(System.in);
    System.out.println("Enter Your Age:");
    age=keyboard.nextInt();
    
    //show output
    System.out.println("Your Age is:"+age);
}
}
