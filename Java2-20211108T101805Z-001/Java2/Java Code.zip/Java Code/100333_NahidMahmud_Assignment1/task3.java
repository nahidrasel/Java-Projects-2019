/**
 * This program will calculate and print a restaurant,customer’s name & bill.
 *
 * @author (Nahid Mahmud)
 * @version (a version number or a date)
 */
import java.util.*;
public class task3
{
    public static void main(String[] args){
        
        //declare the name of the restaurant,customer & bill,tip,tax ,total bill
        String restaurantname,customername;
        double bill,tip,tax,totalpay;
        
        //Enter the name of restaurant & customer
        Scanner keyboard=new Scanner(System.in);
        System.out.println("Enter the name of the restaurant:");
        restaurantname=keyboard.nextLine();
        System.out.println("Enter the name of the customer:");
        customername=keyboard.nextLine();
 
        //Enter the amount of bill,tip & tax;
        System.out.println("Enter the amount of bill:");
        bill=keyboard.nextDouble();
        System.out.println("Enter the amount of tip:");
        tax=keyboard.nextDouble();
        System.out.println("Enter the amount of tax:");
        tip=keyboard.nextDouble();
        
        //Calculate the total pay 
        
        tax=bill*(tax/100);
        totalpay=bill+tip+tax;
        
        //Display the total to payable with restaurant and customer name
        
        System.out.println(" **********************************");
        System.out.println(" Welcome to the " + restaurantname + ",s restarurant ");
        System.out.println(" **********************************");
        System.out.println("                                      ");
        System.out.println(" CUSTOMER   NAME : " + customername);
        System.out.println(" ===================================");
        
        
        System.out.println(" The Amount of bill is : " + bill+ " dollar");
        System.out.println(" The Amount of tip is  : " + tip+ " dollar");
        System.out.println(" The Amount of tax is  : " + tax+" dollar");
        System.out.println("                                          ");
        System.out.println(" TOTAL TO PAY  :  " +totalpay+ " dollar");
        System.out.println("                                          ");
        
        System.out.println(" ===================================");
        System.out.println(" *********** THANK YOU  ************");
    }
}