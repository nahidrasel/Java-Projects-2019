
/**
 * This program will calculte the area and perimeter of some shapes.
 *
 * @author (Nahid Mahmud)
 * @version (a version number or a date)
 */
import java.util.*;
public class task1
{
    public static void main(String[] args){
        
       //declare the radius,area,perimeter,lenth,width and side of a circle,rectangular&square
       double radius,area,perimeter,length,width,side1;
       
       //Get the input from user of radius of a circle
       System.out.println("Enter the radius of circle:");
       Scanner keyboard=new Scanner(System.in);
       radius=keyboard.nextDouble();
       
       //calculate the area of circle
       area=3.1416*radius*radius;
       System.out.println("The area of circle is:"+area);
       
       //calculate the perimeter of circle
       perimeter=2*3.1416*radius;
       System.out.println("The perimeter of circle is:"+perimeter);
       
       //Get the input from user of length of a rectangular
       System.out.println("Enter the lenght of rectangular:");
       length=keyboard.nextDouble();
       
       //Get the input from user of width of a rectangular
       System.out.println("Enter the width of rectangular:");
       width=keyboard.nextDouble();
       
       //calculate the area of rectangular
       area=length*width;
       System.out.println("The area of rectangular is:"+area);
       
       //calculate the perimeter of rectangular
       perimeter=2*length+2*width;
       System.out.println("The perimeter of rectangular is:"+perimeter);
       
       //take the value of a side of a square
       System.out.print(" Enter the value of one side: ");
       side1=keyboard.nextDouble();
       
       //calculate the area of square
       area=side1*side1;
       System.out.println("The area of square is:"+area);
       
       //calculate the perimeter of circle
       perimeter=4*side1;
       System.out.println("The perimeter of square is:"+perimeter);
    }

}
