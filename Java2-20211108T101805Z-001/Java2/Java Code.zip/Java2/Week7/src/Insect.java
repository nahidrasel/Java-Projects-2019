
public class Insect {
	private double size;
	private String color;

	// a constructor with two inputs

	public Insect(double size, String color) {
		this.setSize(size);// this.Set.size=size;
		this.setColor(color);//
	}

	/* String to String method */
	public String toString() {
		return "Size is :" + size + "\nColor is :" + color + "\n";
	}

	/******* other methods *******/
	public void attack() {
		System.out.println(" Insect is attacking");
	}

	public void moving() {
		System.out.println(" Insect is moving");
	}

	public boolean isDengerous() {
		return false;
	}

	public boolean canFly() {
		return false;
	}

	public void setSize(double size) {
		this.size = size;
	}

	public double getSize() {
		return size;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
}
