public class FullTime extends Employee {

	double salary;

	public FullTime(int ID, String name, double salary) {
		super(ID, name);
		this.salary = salary;
	}

	public void pay() {
		System.out.println(getName() + " will be paid " + salary);
	}

	// override
	public String toString() {
		return super.toString() + "FullTime [salary= " + salary + "]";
	}

	public double getsalary() {
		return salary;
	}

	public void setsalary(double salary) {
		this.salary = salary;
	}
}