import java.util.Scanner;

public class TestEmployee {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		Employee b = new Employee(10, "Nahid");
		System.out.println(b);
		b.getName();
		b.pay();

		System.out.println("****************");

		FullTime f = new FullTime(11, "k", 8500);
		System.out.println(f);
		f.pay();

		System.out.println("****************");

		PartTime p = new PartTime(12, "D", 20, 17.70);
		p.pay();
		p.calcBonus();
		p.addHours(5);
		p.pay();
		System.out.println(p);
		System.out.println("****************");
	}

}
