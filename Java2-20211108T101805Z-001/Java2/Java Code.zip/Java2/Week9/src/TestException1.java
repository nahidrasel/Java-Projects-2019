import java.util.InputMismatchException;
import java.util.Scanner;

public class TestException1 {
	public static void main(String[] args) {
		System.out.println("Program starts");
		System.out.println("-------------------");
		try {
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter the first number");
			int number1=scan.nextInt();
			System.out.println("Enter the second number");
			int number2=scan.nextInt();
			int result=number1/number2;
			System.out.println("The result is:"+result);
		}
		
		catch(ArithmeticException e) {
			System.err.println("You cannot divided by zero");
		}
		catch(InputMismatchException e) {
			System.err.println("Only integer");
		}
		catch(Exception e) {
			System.err.println("something wrong");
		}
		finally {
			System.out.println("finally is executed");
		}
	}

}
