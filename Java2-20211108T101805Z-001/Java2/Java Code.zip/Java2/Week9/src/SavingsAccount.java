
public class SavingsAccount extends BankAccount {
	private String address;

	public SavingsAccount(String username, double balance, String address) {
		super(username, balance);
		this.address = address;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double interest() {

		return 1.5;
	}

	public void setUsername(String username) {

	}

}
