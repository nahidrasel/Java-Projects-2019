public class CreditAccount extends BankAccount {
	private String fullName;

	public CreditAccount(String username, double balance, String fullName) {
		super(username, balance);
		this.fullName = fullName;
	}

	public double interest() {

		return 0.135;
	}

	public void setUsername(String username) {
		if (username == null || username.isEmpty())
			throw new BankAccountException("username can not be null or empty");
		if (username.length() != 8) {
			throw new BankAccountException("username must be 8 letters");
		}
		this.username = username;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	// String to String Method
	public String toString() {
		return super.toString() + "CreditAccount [fullName=" + fullName + "]";
	}
}