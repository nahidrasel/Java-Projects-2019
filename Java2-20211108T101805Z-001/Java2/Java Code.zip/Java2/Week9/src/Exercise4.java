
public class Exercise4 {
	public static void main(String[] arg) {
		
		String str="The sky is blue";
		System.out.println("# of letters:"+str.length());
		
		String str1="";
		System.out.println("# of letters:"+str1.length());
		
		try {
		String str3 =null;
		System.err.println("# of letters:"+str3.length());
		}
		catch(NullPointerException e){
			System.out.println("Initialize it before using it");
			System.err.println(e.getMessage());
		}
		
	}

}


//multiple choice
//output
//write code on the pc
