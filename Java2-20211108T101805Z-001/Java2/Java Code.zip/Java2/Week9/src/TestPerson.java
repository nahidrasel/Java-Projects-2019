
public class TestPerson {
	public static void main(String [] args) throws NahidException, AgeException {
		try {
			Person p=new Person("Nahid",21);
			p.setName(null);
			p.setName("");
			System.out.println(p);
		}
		catch(NahidException e){
				System.out.println(e.getMessage());
			}
		try {
			Person a=new Person("Nahid",12);
			a.setAge(0);
			System.out.println(a);
		}
		catch(AgeException q){
			
			System.out.println(q.getMessage());
		}
		}
}