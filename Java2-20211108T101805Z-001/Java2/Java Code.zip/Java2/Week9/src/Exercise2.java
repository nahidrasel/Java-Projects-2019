
public class Exercise2 {

	public static void main(String[] args) {
		try{
			int a []= new int [10];
			a[10]=90;
		System.out.println(a[10]);
	}
	catch(ArrayIndexOutOfBoundsException e) {
		System.err.println("Check the index");
	}
	finally {
		System.out.println("Cose ends");

	}
		try {
			int [] array= {10,30,50,70,90,110};
			for (int i=0;i<array.length;i++) {
				System.out.println(array[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Check the index");
		}
}
}
