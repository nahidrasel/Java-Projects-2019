
public class BankAccountException extends IllegalArgumentException{
	
	public BankAccountException() {
		super("Invalid username or account balance");
	}
	
	public BankAccountException(String msg) {
		super(msg);
	}
}
