
public abstract class BankAccount {
	
	// variables
	protected String username;
	private double balance;

	// abstract methods
	public abstract double interest();

	public abstract void setUsername(String username);

	// constructor
	public BankAccount(String username, double balance) {
		this.username = username;
		this.balance = balance;
	}

	// Deposit method
	public void deposit(double amount) {
		if (amount > 0)
			balance = balance + amount;
	}

	// Withdraw Method
	public void withdraw(double amount) {
		if (amount <= balance) {
			balance = balance - amount;
		} else
			System.out.println("You don't have enough credit");
	}

	// Override toString method
	public String toString() {
		return super.toString()+
		 "BankAccount [username=" + username + ", balance=" + balance + "]";
	}

	public double getBalance() {
		return balance;
	}

	public String getUsername() {
		return username;
	}

}