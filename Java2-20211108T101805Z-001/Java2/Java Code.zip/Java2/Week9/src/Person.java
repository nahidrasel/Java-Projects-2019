
public class Person {
	private String name;
	private int age;

	// Constructor with two input
	public Person(String name, int age) throws NahidException, AgeException {
		this.setName(name);
		this.setAge(age);
	}

	// Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}

	// Set & Get Method
	public String getName() {
		return name;
	}

	public void setName(String name) throws NahidException {
		if(name==null || name.isEmpty())
			throw new NahidException("Name can't be null or empty");
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age)throws AgeException {
		if(age<=0)
			throw new AgeException("Age can't be less than zero");
		this.age = age;
	}
}