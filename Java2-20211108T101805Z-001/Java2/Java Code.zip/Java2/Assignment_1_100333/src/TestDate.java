import java.util.Scanner;
public class TestDate {
	public static void main(String[] args) {
			Scanner scan=new Scanner (System.in);
			
			Date s1=new Date();
						
				System.out.println("--------");
				s1.setMonth(2);
				s1.setDay(9);
				s1.setYear(2019);
				s1.leapyear();
				s1.monthcount();
				
					/*
			
					s2.printDetails();
	*/
			}
					
		}
