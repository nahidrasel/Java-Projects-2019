import java.util.Scanner;

public class DessertShoppe {
	public final static double TAX_RATE = 6.5; // 6.5%
	public final static String STORE_NAME = "M & M Dessert Shoppe";
	public final static int MAX_ITEM_NAME_SIZE = 25;
	public final static int COST_WIDTH = 6;

	public static String cents2dollarsAndCents(int cents) {
		String s = "";

		if (cents < 0) {
			s += "-";
			cents *= -1;
		}

		int dollars = cents / 100;
		cents = cents % 100;

		if (dollars > 0)
			s += dollars;

		s += ".";

		if (cents < 10)
			s += "0";

		s += cents;

		return s;
	}

	static int cprice;
	static int candy;

	static int ice;
	static int sun;
	static int piece;

	public static void printMenu() {

		System.out.println(" Choose an Iteam");
		System.out.println("1- Candy");
		System.out.println("2- Cookie");
		System.out.println("3- Ice cream");
		System.out.println("4- Sundae");
		System.out.println("5- exit");
	}

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		System.out.println("Enter your name:");
		String name = scan.nextLine();
		System.out.println("Hi, " + name);
		System.out.println("Welcome to ICL DESSERT SHOP");
		DessertShoppe[] list = new DessertShoppe[5];

		for (int i = 0; i < list.length; i++) {

			System.out.println("Which one you want to buy");
			printMenu();
			int choice = scan.nextInt();
			scan.nextLine();

			if (choice == 1) {
				System.out.println("OK, you want Candy, How much pound you need? ");
				int pound = scan.nextInt();

				candy = pound * 10;

			} else if (choice == 2) {
				System.out.println("OK, you want Cookies, How many pieces you need? ");
				int pieces = scan.nextInt();
				piece = pieces * 2;

			}

			else if (choice == 3) {
				System.out.println("OK, you want Ice Cream, how many you need? ");
				int number = scan.nextInt();
				ice = number * 2;
			} else if (choice == 4) {
				System.out.println("OK, you want sundae, how many you need? ");
				int number = scan.nextInt();
				sun = number * 5;
			} else {
				System.out.println("Your total price is below");

				break;
			}

		}
		double total = candy + ice + sun + piece;
		System.out.println("Total Price :" + total);
		double tax = (total * 0.65) + total;
		System.out.println("after tax=" + tax);
		System.out.println("Enter the money to pay:");
		double number = scan.nextInt();
		System.out.println("You will have back:");
		double back = number - tax;
		System.out.println("=" + back);
		System.out.println("Enjoy");

	}
}
