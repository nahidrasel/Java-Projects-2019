
public abstract class Shape {
	private int xCord;
	private int yCord;

	// abstract methods
	public abstract double area();

	public abstract double perimeter();
	
	public Shape(int xCord, int yCord) {
	this.xCord=xCord;
	this.yCord=yCord;
	}

	/******** to string method ****************/
	// overriding
	public String toString() {
		return "Shape [xCoord=" + xCord + ", yCoord=" + yCord + "]";
	}

	/**************** move method *********************/
	public void move(int newXcor, int newYcor) {
		this.xCord = newXcor;
		this.yCord = newYcor;
	}

	/************** Area method ***************/
	
	// overloading

	public void move(int radius) {
		System.out.println("");
	}
	// get
	public int getxCoord() {
		return xCord;
	}

	public int getyCoord() {
		return yCord;
	}

	// set
	public void setxCoord(int xCord) {
		this.xCord = xCord;
	}

	public void setyCoord(int yCord) {
		this.yCord = yCord;

}
}
