
public class Cow extends Animal {
	
	public Cow(String name) {
		super(name);
	
	}

	public void makeNoise() {
		
		System.out.println("Moo ! Moo !");
	}

	//Override
	public void walk() {
		System.out.println(" ");
	}

}