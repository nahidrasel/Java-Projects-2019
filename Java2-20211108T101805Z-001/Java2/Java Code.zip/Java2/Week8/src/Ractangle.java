
public class Ractangle extends Shape {
	
	private int weight;
	private int height;

	public Ractangle(int xCord, int yCord, int height, int weight) {
		super(xCord, yCord);
		this.height = height;
		this.weight = weight;
	}

//get and set
	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	 //Override
	public String toString() {
		return "Ractangle details"
				+ " [weight=" + weight + ", height=" + height + ", getWeight()=" + getWeight() + ", getHeight()="
				+ getHeight() + ", area()=" + area() + ", perimeter()=" + perimeter() + "]";
	}

	// Area method override
	public double area() {
		return  height * weight;
	}

	//override perimeter method
	
		public double perimeter() {
			return 2*(height*weight);
		}
}
