
public class Circle extends Shape {
	private int radius;

	@Override
	public String toString() {
		return "Circle details "
				+ " [radius=" + radius + ", area()=" + area() + ", perimeter()=" + perimeter() + "]";
	}

	public Circle(int xCord, int yCord, int radius) {
		super(xCord, yCord);
		this.radius = radius;
	}

	// get
	public int getRadius(int radius) {
		this.radius=radius;;
		return radius;
	}
	// set

	public void setRadius(int radius) {
		this.radius = radius;
	}

	// Override
	public double area() {
		
		return 3.1416 * radius * radius;
	}

	// over ride
	public double perimeter() {

		return 0;
	}
}
