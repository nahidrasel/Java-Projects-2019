
public class EqTriangle extends Shape {
	private int sideLength;

	public EqTriangle(int xCord, int yCord, int sideLength) {
		super(xCord, yCord);
		this.sideLength = sideLength;
	}

	//Override Area method override
	public double area() {
		
		return  (Math.sqrt(3.0)* sideLength*sideLength)/4;
	}
	//override perimeter method
	
	public double perimeter() {
		return 3*sideLength;
		
	}
	//Override toString method
	public String toString() {
		return "EqTriangle [sideLength=" + sideLength 
				+"\nArea"+area()
				+"\nPerimeter ="+perimeter();
	}
	// get and set
		public int getSideLength() {
			return sideLength;
		}
		public void setSideLength(int sideLength) {
			this.sideLength = sideLength;
		}
}

