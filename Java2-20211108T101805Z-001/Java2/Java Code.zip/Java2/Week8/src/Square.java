
public class Square extends Shape {

	private int side;

	// constructor

	public Square(int xCord, int yCord, int side) {
		super(xCord, yCord);
		this.side=side;
	}
	public double area() {
		return  getSide() * getSide();
	}
	// override
		public double perimeter() {

			return 4*getSide();
		}
//get and set
	public int getSide() {
	return getHeight();
	}
	
	private int getHeight() {
		return 0;
	}
	//Override
	public String toString() {
		return "Square  details"
				+ "[side=" + side + ", getSide()=" + getSide() + ", area()=" + area() + ", perimeter()="
				+ perimeter() + "]";
	}
}