
public class Mobile {
	
		private String brandName;
		private int bettary;
		private int speed;

		public String toString()
		{
			return "Brand name is "+brandName
					+"\nBettary MAH ="+bettary
					+"\nSpeed is :"+speed+"Ghz"
					+"\nTotal Score ="+totalScore();
		}

		public void setbrandName(String brandName) {
			this.brandName= brandName;
		}

		public String getbrandName() {
			return brandName;
		}

		public void setBettary(int bettary) {
			this.bettary = bettary;
		}

		public int getBettary() {
			return bettary;
		}

		public void setSpeed(int Speed) {
			this.speed= speed;
		}

		public Mobile() {
			this.brandName="Apple";
			this.bettary=4000;
		    this.speed=4;
		}

		public Mobile(String brandName) {
			this.brandName=brandName;
			this.bettary=bettary;
		    this.speed=speed;
		}

		public Mobile(String brandName,int bettary) {
			this.brandName=brandName;
			this.bettary=bettary;
		    this.speed=speed;
		}
		    public Mobile(String brandName,int bettary,int speed) {
				this.brandName=brandName;
				this.bettary=bettary;
			    this.speed=speed;
		}

		public int totalScore() {
			return speed*bettary;
		}

}