import java.util.*;
public class TestAuthor {

	public static void main(String[] args) {
		Author a = new Author("John","Jhon@gmail.com",'M');
		int [] numbers= new int[5];
		numbers[0]=300;
		numbers[1]=200;
		numbers[2]=100;
		numbers[3]=50;
		numbers[4]=10;
		
		for(int i=0;i<numbers.length;i++) {
			System.out.println(numbers[i]+" ");
		}
		System.out.println("\n----------------");
		
		Author[] list=new Author[3];
		list[0]=new Author("John","John@gmail.com",'M');
		list[1]=new Author("James","James@gmail.com",'M');
		list[2]=new Author("Sarah","Sarah@gmail.com",'M');
		
		list[1].setEmail("James22@gmail.com");
		for(int i=0;i<list.length;i++) {
		if(list[1].checkEmail()) {
			System.out.println("Email"+ (i+1)+ "Correct");
		}
		else {
		System.out.println("Email"+ (i+1)+"InCorrect");
		}
		}
		for(int i=0;i<list.length;i++) {
			System.out.println(list[i]);
		}
		System.out.println("---------------------");
	}
	}