
public class School {
	private String name;
	private Student[] list;
	private final int MAX_SIZE = 100; // constant

	public String toString() {
		return "School:" + name +",has:"+printStudents();
	}

	public School() {
		this.name = name;
		this.list = new Student[MAX_SIZE];
	}

	public School(String name, Student[] list) {
		this.name = name;
		this.list = list;
	}

	/***********************************/

	public String printStudents() {
		String str = "";
		for (int i = 0; i < list.length; i++) {
			str = str + list[i] + "\n";
		}
		return str;
	}

	public void setname(String name) {
		this.name = name;
	}

	public String getname() {
		return name;
	}

	public void setlist(Student[] list) {
		this.list = list;
	}

	public Student[] getlist() {
		return list;
	}
}
