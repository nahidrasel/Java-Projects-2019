
public class Student {
	private int id;
	private String name;
	private Address address ; // HAS -A relationship
	
	public Student(int id,String name,Address address) {
		this.id=id;
		this.name=name;
		this.address=address;
	}
	public String toString() {
		return  "Student:"+ ""+id +" " +name +" "+ address;
	}
	public void setid(int id) {
		this.id=id;
	}
	public int getid() {
		return id;
	}
	public void setname(String name) {
		this.name=name;
	}
	public String getname() {
		return name;
	}
	public void setaddress(Address address) {
		this.address=address;
	}
	public Address getaddress() {
		return address;
	}
}

