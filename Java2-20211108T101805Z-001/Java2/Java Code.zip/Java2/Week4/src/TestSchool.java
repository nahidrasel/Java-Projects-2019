import java.util.*;

public class TestSchool {

	public static void main(String[] args) {
		
		// create an object
		Address a1 = new Address(21, "Tait st", "Auckland");
		Address a2 = new Address(25, "Tent st", "Auckland");
		Address a3 = new Address(121, "Pt CHEv st", "Auckland");

		Student s = new Student(32, "John", a1);

		// create an array of 5-10 Student
		Student[] list = new Student[5];
		list[0] = new Student(111, "John", a1);
		list[1] = new Student(131, "Samin", a2);
		list[2] = new Student(1211, "Ardina", a3);
		list[3] = new Student(141, "Mark", new Address(25, "Tent", "Auckland"));
		list[4] = new Student(191, "Momen", new Address(154, "Mangere", "Hamilton"));

		// create an object From the School Class
		School icl = new School("Icl Business", list);
		System.out.println(icl);
	}
}
