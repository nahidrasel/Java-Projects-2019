
public class Address {
	private int streetNo;
	private String streetName;
	private String city;

	public Address(int streetNo, String streetName, String city) {
		this.streetNo = streetNo;
		this.streetName = streetName;
		this.city = city;

	}

	public String toString() {
		return "" + streetNo + " " + streetName + " Street " + city+"City";
	}

	public void setstreetNo(int streetNo) {
		this.streetNo = streetNo;
	}

	public int getstreetNo() {
		return streetNo;
	}

	public void setstreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getstreetName() {
		return streetName;
	}

	public void setcity(String city) {
		this.city = city;
	}

	public String getcity() {
		return city;
	}
}
