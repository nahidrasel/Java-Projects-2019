
import java.util.Scanner;

public class TestCircle {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
/*
		Circle c1 = new Circle();
		System.out.println("Enter the Color:");
		c1.setColor(scan.nextLine());

		System.out.println("Enter the radius:");
		c1.setRadius(scan.nextDouble());

	
*/
		Circle c3 =new Circle();
		
		System.out.println(c3);

	}

}
