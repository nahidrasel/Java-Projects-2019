
public class TestMobile {

	public static void main(String[] args) {
		Mobile a = new Mobile();
		System.out.println(a);

	}
	}
