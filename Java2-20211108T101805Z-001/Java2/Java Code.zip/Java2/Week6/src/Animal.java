
public class Animal {
	private String FavouriteFood;

	public void thoughts() {
		System.out.println("I am an animal, I don't know what I want to eat");
	}

	public void talk() {
		System.out.println("Hello");
	}

	public void eat() {
		System.out.println("Animal is eating" + FavouriteFood);
	}

	/***************************************/
	public void setFavouriteFood(String food) {
		FavouriteFood = food;
	}
	public String getFavouriteFood() {
		return FavouriteFood;
	}

}
