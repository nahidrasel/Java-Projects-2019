import java.time.LocalDate;

public class Date {
	int month;
	int day;
	int year;
	int leapyear;
	int monthcount;
	int dayOfYear;
	
	public Date() {
		this.month =1 ;
		this.day = 1;
		this.year =1990 ;
	}
	public Date(int monthValue, int dayValue, int yearValue) {
		this.setMonth(0);
		this.setDay(1);
		this.setYear(0);
	}
	public void setMonth(int monthValue) {
		if (month > 0 && month <= 12) {
			month = monthValue;
		} else {
			this.month = 0;
		}
	}

	public int getMonth() {
		return month;
	}

	public void setDay(int dayValue) {
		if (day > 0 && day <= 31) {

			day = dayValue;
		} else
			this.day = 0;
	}
	public int getDay() {
		return day;
	}
	public int getYear() {
		return year;
	}

	public void setYear(int yearValue) {
		if (year > 0 && year <= 2018) {
			year = yearValue;
		} else
			this.year = 0;
	}

	public int getyear() {
		return year;
	}

	public void leapyear() /* ref:website name */
	{
		if (year % 4 == 0 || year % 100 == 0 || year % 400 == 0) {
			System.out.println("Leap year:Yes");
		}
	}

	public void  monthcount() {
		if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
			System.out.println("Days: 31");
		}
		else if (month == 4 || month == 6 || month == 9 || month == 11) {
			System.out.println("Days: 30");
		} 
		else if(month==2) {
        if ((year % 400 == 0) || ((year % 4 == 0) && (year % 100 != 0))) {
            System.out.println("Days:29 ");
        } 
        else 
        	System.out.println("Days: 28");
		}
		
	}
	/*public int dayOfYear(int year, int month, int day) // 0<month<=12

	{
		short[] daysInMonth = new short[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

		if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))

			daysInMonth[1] = 29;

		int yearDay = 0;

		for (int i = 0; i < month - 1; i++)

		{

			yearDay += daysInMonth[i];

		}

		yearDay += day;

		return yearDay;
	}
	}
	LocalDate start = LocalDate.of( 2017 , 2 , 23 ) ;
	LocalDate stop = LocalDate.of( 2017 , 3 , 11 ) ;
	int daysBetween = ChronoUnit.DAYS.between( start , stop );

	/*
	 * //Override a method called "toString" public String toString() { return
	 * "DD :" +day +" MM  :" +month +" YYYY : " +year; }
	 */
		
	public void printDetails() {// need to set String to String Method
		System.out.println("Month:" + month);
		System.out.println("Day:" + day);
		System.out.println("Year:" + year);
		System.out.println(monthcount());
	}
}
