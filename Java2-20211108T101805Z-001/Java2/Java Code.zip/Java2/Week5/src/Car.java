
public class Car {
	private String color;
	private String brandName;
	private Engine engine;// HAS -A relationship

	public Car(String color, String brandName, Engine engine) {
		this.color = color;
		this.brandName = brandName;
		this.engine = engine;
	}

	public String toString() {
		return "Car:"+ color + " " + brandName + " has " + engine +"Engine";
	}

	public void setcolor(String color) {
		this.color = color;
	}

	public String getcolor() {
		return color;
	}

	public void setbrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getbrandName() {
		return brandName;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public Engine getengine() {
		return engine;
	}
}
