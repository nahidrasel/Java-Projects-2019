
public class TestCar {

	public static void main(String[] args) {
			
			// create an object
			Engine a1 = new Engine(1.5,"Diesel");
			Engine a2 = new Engine(1.8,"Petrol");
			Engine a3 = new Engine(2.0,"Hybrid");

			
			// create an object From the School Class
			Car mazda = new Car("Red"," Mazda",a1);
			Car corolla = new Car("Blue"," Corolla",a2);
			Car audi = new Car("Black"," Audi",a3);
			System.out.println(mazda);
			System.out.println("--------------");
			System.out.println(corolla);
			System.out.println("--------------");
			System.out.println(audi);
			System.out.println("--------------");
		}
	}

