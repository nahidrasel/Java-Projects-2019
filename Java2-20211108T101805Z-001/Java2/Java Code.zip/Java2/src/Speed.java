import java.util.Scanner;

public class Speed {
	
	public static void main(String[] args) {

		int speed, distance, time;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the distance");
		distance = scan.nextInt();
		
		System.out.println("Enter the time");
		time = scan.nextInt();
		
		speed = distance / time;
		System.out.println("Your Speed is :" + speed + "km/hr");
	}
}
