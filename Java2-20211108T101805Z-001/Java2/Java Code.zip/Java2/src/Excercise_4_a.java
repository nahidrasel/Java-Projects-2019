import java.util.Scanner;

public class Excercise_4_a {

	public static void main(String[] args) {
		int mark;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter an number:");
		mark=scan.nextInt();
		
		if(mark%2 == 0) {
			System.out.println("Even");
		}
		else 
			System.out.println("Odd");
	}
	}
