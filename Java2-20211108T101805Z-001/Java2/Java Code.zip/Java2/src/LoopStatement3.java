import java.util.Scanner;

public class LoopStatement3 {

	public static void main(String[] args) {
		int limit;
		
		Scanner scan = new Scanner(System.in);

		for (int row = 1; row <= 9; row++) {
			System.out.print(row+":");
			for(int column=1;column<=9;column++) {
				int m=row*column;
		System.out.print(" " +m+" ");
		}
		
		System.out.println(" ");
	}
}
}