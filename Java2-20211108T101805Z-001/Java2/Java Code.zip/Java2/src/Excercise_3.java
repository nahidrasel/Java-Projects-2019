import java.util.Scanner;

public class Excercise_3 {
	
	public static void main(String[] args) {
		
		int mark;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("What is your mark:");
		mark=scan.nextInt();
		
		if(mark>=50) {
			System.out.println("pass");
		}
		else 
			System.out.println("fail");
	}
}
