import java.util.Scanner;

public class LoopStatement1 {
	public static void main(String[] args) {

		int n, number;
		double average = 0, sum = 0;
		Scanner scan = new Scanner(System.in);

		System.out.println("How many numbers would you like to input");
		n = scan.nextInt();
		
		for (int i = 1; i <= n; i++) {
			number = scan.nextInt();
			sum = sum + number;
		}
		System.out.println("The Sum is :" + sum);
		average = sum / n;
		
		System.out.println("The average is :" + average);
	}

}
