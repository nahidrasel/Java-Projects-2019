import java.util.Scanner;

public class ArrayTest {

	public static void main(String[] args) {
		int numberOfStudent,grade;
		double average,maximum,minimum;
		Scanner scan=new Scanner(System.in)
		
	}

}
