
public class LineType {

}
