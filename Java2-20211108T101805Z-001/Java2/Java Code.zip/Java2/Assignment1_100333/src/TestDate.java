import java.util.Scanner;

public class TestDate {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Date a = new Date(07, 30, 2019);
		System.out.println(a);
		a.leapyear();
		a.monthcount();
		a.dayspassed();
		a.daysremaining();
		a.compare();
	}
}