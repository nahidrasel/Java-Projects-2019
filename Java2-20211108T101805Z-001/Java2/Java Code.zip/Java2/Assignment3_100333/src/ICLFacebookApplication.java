import java.io.IOException;
import java.util.Scanner;

public class ICLFacebookApplication {

	public static void main(String[] args) throws IOException {
		Scanner scan = new Scanner(System.in);

		System.out.println("**************************");
		System.out.println("*Welcome to ICL Facebook Application*");
		Account a = new Account();//create object from  class
		a.createDatabase();

		System.out.println("Do you have an account? Y/N");
		char choice = scan.next().charAt(0);
		if (choice == 'Y' || choice == 'y') {
			System.out.println("Do you like to login? Y/N");
			 choice= scan.next().charAt(0);

			if (choice == 'Y' || choice == 'y') {
				System.out.println("please enter your username:");
				String username = scan.nextLine();
				String next = scan.nextLine();
				System.out.println("please enter your password");
				String password = scan.nextLine();
				System.out.println("Congratulation You have logged in successfully!");
				a.login(username, password);
			} else
				System.out.println("You can try later !\n Have a Nice Day");

		} 
		else {
			System.out.println("Do you like to create a new account? Y/N");
			choice = scan.next().charAt(0);
			if (choice == 'Y' || choice == 'y') {
				a.createNewAccount(a.getName(), a.getUsername(), a.getPassword());
				System.out.println("Check email =" + a.checkEmailFormat());
			}
		}

			System.out.println("What do you wish to post?\n ");
			System.out.println("1.Text\n 2.Video\n 3.Photo");
			int wish = scan.nextInt();
			if (wish == 1) {

				Text t = new Text();//create from each class
				System.out.println("Please enter the message");
				t.setMessage(scan.nextLine());
				System.out.println("please enter your color");
				String line = scan.nextLine();
				t.setColor(scan.nextLine());
				System.out.println("please enter font size");
				t.setFontSize(scan.nextInt());
				System.out.println(t);
				t.changeToUpperCase();
				t.loveSymbol();
				t.dislike();
				t.like();
			} else if (wish == 2) {
				Video v = new Video();//create from each class
				System.out.println("please enter your seconds");
				v.setSeconds(scan.nextInt());
				
				System.out.println("please enter your minutes");
				v.setMinutes(scan.nextInt());
				System.out.println("please enter your Title");

				v.setTitle(scan.nextLine());
				System.out.println(v);
				v.dislike();
				v.laughFace();
				v.sadFace();
			} else if (wish == 3) {

				Photo p = new Photo();//create from each class
				System.out.println("please enter your Name");
				p.setName(scan.nextLine());
				System.out.println("please enter your Width");
				p.setWidth(scan.nextInt());
				System.out.println("please enter your Height");
				p.setHeight(scan.nextInt());
				System.out.println("please enter your Size");
				p.setSize(scan.nextInt());
				System.out.println(p);
				p.CompressPhoto();
				p.dislike();
				p.like();
				p.loveSymbol();
				p.laughFace();
			}
			
			else
				System.out.println("Will see you back again");
			System.out.println("Good bye for now ! ");	
	}
}
