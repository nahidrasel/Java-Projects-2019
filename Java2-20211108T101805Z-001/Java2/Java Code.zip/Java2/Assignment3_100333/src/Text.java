import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Text implements StatusAction {
	private static final int NumberOflike = 0;
	private static final int NumberOfDislike = 0;
	private String message;
	private String color;
	private int fontSize;
	private String filename = "Message.txt";

	// Constructor.
	public Text() {
		super();
	}

	// upper case method.
	public String changeToUpperCase() {
		message = message.toUpperCase();
		return message;
	}

	// number of letters methods
	public int getNumberOfLetters() {
		int num = 0;
		for (int i = 0; i < message.length(); i++) {
			if (Character.isLetter(message.charAt(i))) {
				num++;
			} else if (message.charAt(i) == ' ') {
				num++;
			}
		}
		return num;
	}

	// contains number methods
	public boolean containNumbers() {
		for (int i = 0; i < message.length(); i++) {
			if (Character.isDigit(message.charAt(i))) {
				return true;
			}
		}
		return false;
	}

	// post methods
	public boolean post() {
		System.out.println(getFilename() + " has posted: " + message);
		return true;
	}

	// hide post methods
	public boolean hidePost() {

		return true;
	}

	// Save message methods
	public boolean saveMessage() {
		try {
			FileWriter writer = new FileWriter(new File(filename), true);
			writer.write(message + "\n");
			writer.close();
		} catch (IOException e) {
			return false;
		}
		return true;
	}

	// Set & Get methods.
	public String getMessage() {
		return message;
	}

	public String getColor() {
		return color;
	}

	public int getFontSize() {
		return fontSize;
	}

	public String getFilename() {
		return filename;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setFontSize(int i) {
		this.fontSize = i;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	// to string methods
	public String toString() {
		return "Statues=" + message + ", color=" + color + ", fontSize=" + fontSize + ", filename=" + filename;
	}

	// Override
	public void like() {

	}

	// Override
	public void dislike() {

	}

	// Override
	public void loveSymbol() {

	}

	// Override
	public void sadFace() {

	}

	// Override
	public void laughFace() {

	}

	public static int getNumberOfLike() {
		return NumberOflike;
	}

	public static int getNumberOfDisLike() {
		return NumberOfDislike;
	}

	// Override
	public int getNumberOfLoveSymbol() {
		return 0;
	}

	// Override
	public int getNumberOfSadFace() {
		return 0;
	}

	// Override
	public int getNumberOfLaughFace() {
		return 0;
	}

	// Override
	public void makeRandomNumberforEach() {
	}
}