
public class Photo implements StatusAction {
	private static final int NumberOflike = 0;
	private static final int NumberOfDislike = 0;
	private String name;
	private int width;
	private int height;
	private int size;

	// Constructor.

	public Photo() {
		super();
	}

	// post method
	public boolean post() {
		System.out.println(getName() + " has posted: " + name + " photo");
		return true;
	}

	// hide methods
	public boolean hidePost() {

		return true;
	}

	// width and height of the photo.
	public boolean TrimPhoto(int w, int h) {
		if (w > width || w < 0 || h > height || h < 0) {
			return false;
		}
		else {
		width =width- w;
		height = height-h;
		}
		return true;
	}

	// Decreases the photo by 30% and returns the new size;
	public int CompressPhoto() {
		size =(int) (size* 0.3);
		return size;
	}

	// set and get methods

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	// to string methods
	public String toString() {
		return "Photo name=" + name + ", width=" + width + ", height=" + height + ", size=" + size;
	}

	// override
	public void loveSymbol() {
	}

	// override
	public void sadFace() {
	}

	// Override
	public void laughFace() {
	}

	public static int getNumberOfLike() {
		return NumberOflike;
	}

	public static int getNumberOfDisLike() {
		return NumberOfDislike;
	}

	// Override
	public int getNumberOfLoveSymbol() {
		return 0;
	}

	// Override
	public int getNumberOfSadFace() {
		return 0;
	}

	// Override
	public int getNumberOfLaughFace() {
		return 0;
	}

	// Override
	public void makeRandomNumberforEach() {
	}

	// Override
	public void like() {

	}

	// Override
	public void dislike() {

	}
}
