import java.io.IOException;
import java.util.Scanner;

public class ICLFacebookApplication {

	public static void main(String[] args) throws IOException {
		Scanner scan = new Scanner(System.in);
		Account a = new Account();

		System.out.println("**************************");
		System.out.println("*Welcome to ICL Facebook Application*");

		System.out.println("Do you have an account? Y/N");
		char choice = scan.next().charAt(0);
		if (choice == 'Y' || choice == 'y') {
			
			System.out.println("Do you like to login? Y/N");
			choice = scan.next().charAt(0);
			
			if (choice == 'Y' || choice == 'y') {
				System.out.println("Enter your Username:");
				String username = scan.nextLine();
				String line = scan.nextLine();
				System.out.println("Enter your Password");
				String password = scan.nextLine();
				a.login(username, password);
				System.out.println("You have successfully login");
				}
			else
				System.out.println("You can try later !\n Have a Nice Day");

		} else {
			System.out.println("Do you like to create a new account? Y/N");
			choice = scan.next().charAt(0);
			if (choice == 'Y' || choice == 'y') {
				a.createDatabase();
				a.createNewAccount(a.getName(), a.getUsername(), a.getPassword());
				System.out.println("Check email =" + a.checkEmailFormat());
			} else {
				System.out.println("Will see you back again");
			}
		}
		Text t = new Text("", "", "", "");
		t.getMessage();
		t.getColor();
		t.getFontSize();
		t.getFilename();
		t.post();
		t.hidePost();
		t.saveMessage();
		System.out.println(t);
		System.out.println("----------------");

		Video v = new Video(0, 0, "");
		v.getSeconds();
		v.getMinutes();
		v.getTitle();
		v.cutVideo(v.getSeconds(), v.getMinutes());
		v.playVideo();
		System.out.println(v);
		System.out.println("----------------");

		Photo p = new Photo(null, 0, 0, 0);
		p.getName();
		p.getWidth();
		p.getHeight();
		p.getSize();
		p.TrimPhoto(p.getWidth(), p.getHeight());
		System.out.println(p);
		System.out.println("----------------");
	}

}