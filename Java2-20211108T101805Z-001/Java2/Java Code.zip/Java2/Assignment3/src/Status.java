
public abstract class Status {
	private static final int NumberOfDislike = 0;
	private static final int NumberOflike = 0;
	// variables
	private String date;
	protected boolean visible;
	private boolean checkIn;
	protected Account currentUser;

	// Constructor.
	public Status(String date, boolean visible, boolean checkIn, Account currentUser) {
		this.date = date;
		this.visible = visible;
		this.checkIn = checkIn;
		this.currentUser = currentUser;
	}

	// abstract methods
	public abstract boolean post();

	public abstract boolean hidePost();

	// set and get methods
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}

	public boolean isCheckIn() {
		return checkIn;
	}

	public void setCheckIn(boolean checkIn) {
		this.checkIn = checkIn;
	}

	public Account getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(Account currentUser) {
		this.currentUser = currentUser;

	}

	// to string methods
	public String toString() {
		return "Status date=" + date + ", visible=" + visible + ", checkIn=" + checkIn + ", currentUser=" + currentUser;
	}

	public static int getNumberOfLike() {
		return NumberOflike;
	}

	public static int getNumberOfDisLike() {
		return NumberOfDislike;
	}

}
