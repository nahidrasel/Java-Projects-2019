public class ICLFacebookException extends Exception {
	// Constructor.
	public ICLFacebookException() {
		super("There is an error in your input");
	}

	public ICLFacebookException(String msg) {
		super(msg);
	}
}
