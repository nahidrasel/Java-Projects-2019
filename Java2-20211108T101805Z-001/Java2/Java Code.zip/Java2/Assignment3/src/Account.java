import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Account {
	Scanner scanner = new Scanner(System.in);
	// variables name
	private String name;
	private String email;
	private char gender;
	private String username;
	private String password;
	private String birthdate;

	// default constructor
	public Account() {
		super();
	}

	// constructor
	public Account(String name, String email, char gender, String username, String password, String birthdate) {
		this.name = name;
		this.email = email;
		this.gender = gender;
		this.username = username;
		this.password = password;
		this.birthdate = birthdate;
	}

	// To String methods
	public String toString() {
		return "Account name=" + name + ", email=" + email + ", gender=" + gender + ", username=" + username
				+ ", password=" + password + ", birthdate=" + birthdate;
	}

	// create database
	public boolean createDatabase() {

		File myfile;
		try {
			myfile = new File("C:\\Users\\HP-NPC\\Documents\\Java2\\Assignment3\\Facebookdb.txt");
			if (myfile.createNewFile())
				System.out.println("File is created");
			else
				System.out.println("File is already exists! Enter your Details: ");
		} catch (IOException e) {
			System.err.println("Check the path");
		}

		return false;
	}

	// login
	public boolean login(String username, String password) throws IOException {
		File myfile;

		FileReader fr;
		BufferedReader br;

		try {
			myfile = new File("C:\\Users\\HP-NPC\\Documents\\Java2\\Assignment3\\Facebookdb.txt");
			fr = new FileReader(myfile);
			br = new BufferedReader(fr);

			if (!myfile.exists()) {

			String line = " ";
			while ((line = br.readLine()) != null) {
		System.out.println(line = br.readLine());
		if(line.equalsIgnoreCase(username)&&line.equalsIgnoreCase(password)) {
			System.out.println("Username and Password is same");
		}
		else 
			System.out.println("Username and password exists");
			br.close();
			fr.close();
		return true;
			} 
			}
		}
		catch (IOException e) {
			System.out.println("Check the path");
		}
		return false;
	}


	// Create New Account
	public boolean createNewAccount(String name, String username, String password) {
		Scanner scan = new Scanner(System.in);
		File myfile;
		FileWriter fw;
		BufferedWriter bw;

		try {
			myfile = new File("C:\\Users\\HP-NPC\\Documents\\Java2\\Assignment3\\Facebookdb.txt");
			
			if(myfile.exists()) {
			myfile.createNewFile();
			fw = new FileWriter(myfile, true);
			bw = new BufferedWriter(fw);

			System.out.println("please enter your name:");
			this.name=scan.nextLine();

			System.out.println("please enter your email:");
			setEmail(scan.nextLine());
			System.out.println("please enter your gender:");
			gender=scan.next().charAt(0);
			
			System.out.println("please enter your username:");
			String next = scanner.nextLine();
			username = scan.nextLine();
			System.out.println("please enter your password:");
			password = scan.nextLine();

			System.out.println("please enter your birthdate:");
			setBirthdate(scan.next());

			bw.write( ""+name +  ""+username +""+ password);
			System.out.println("Congratulation, a new account has been created successfully!");
			bw.close();
			
			return true;

			}
		}
		catch (IOException e) {
			System.err.println("Check the path");
		}
		return false;
	}

	// Check the email
	public boolean checkEmailFormat() {
		System.out.println("Checking the email format.....");
		String format = "@";
		if (email.contains(format)) {
			System.out.println("The email is correct");
			return true;
		}
		return false;
	}
	// set and get methods

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername() {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword() {
		this.password = password;
	}

	public String getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public int setSeconds() {
		return 0;
	}

}
