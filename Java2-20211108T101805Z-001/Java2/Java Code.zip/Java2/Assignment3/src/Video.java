
public class Video implements StatusAction {
	private static final int NumberOflike = 0;
	private static final int NumberOfDislike = 0;
	private int seconds;
	private int minutes;
	private String title;

	// Constructor

	public Video(int seconds, int minutes, String title) {
		super();
		this.seconds = seconds;
		this.minutes = minutes;
		this.title = title;
	}

	// boolean post
	public boolean post() {
		System.out.println(title + " has posted: " + title + " video.");
		return true;
	}

	// hide post
	public boolean hidePost() {
		return true;
	}

	// cut video methods
	public void cutVideo(int s, int m) {
		seconds -= s;
		if (seconds < 0) {
			seconds += 60;
			minutes -= 1;
		}
		minutes -= m;
		if (minutes < 0) {
			minutes = 0;
			seconds = 0;
		}
	}

	// Play the video.
	public void playVideo() {
		System.out.println(getTitle() + " is played!");
	}

	// Get & Set methods.
	public int getSeconds() {
		return seconds;
	}

	public int getMinutes() {
		return minutes;
	}

	public String getTitle() {
		return title;
	}

	public void setSeconds(int seconds) {
		this.seconds = seconds;
	}

	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	// toString function.
	public String toString() {
		return super.toString() + "," + title + "," + minutes + ":" + seconds;
	}

	// Override
	public void like() {

	}

	// Override
	public void dislike() {

	}

	// Override
	public void loveSymbol() {

	}

	// Override
	public void sadFace() {

	}

	// Override
	public void laughFace() {
	}

	public static int getNumberOfLike() {
		return NumberOflike;
	}

	public static int getNumberOfDisLike() {
		return NumberOfDislike;
	}

	// Override
	public int getNumberOfLoveSymbol() {
		return 0;
	}

	// override
	public int getNumberOfSadFace() {
		return 0;
	}

	// Override
	public int getNumberOfLaughFace() {
		return 0;
	}

	// Override
	public void makeRandomNumberforEach() {
	}
}