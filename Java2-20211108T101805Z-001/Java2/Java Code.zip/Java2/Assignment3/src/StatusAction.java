
public interface StatusAction {

	public void like();

	public void dislike();

	public void loveSymbol();

	public void sadFace();

	public void laughFace();

	public static int getNumberOfLike() {
		return 0;
	}

	public static int getNumberOfDisLike() {
		return 0;
	}

	public int getNumberOfLoveSymbol();

	public int getNumberOfSadFace();

	public int getNumberOfLaughFace();

	public void makeRandomNumberforEach();
}
