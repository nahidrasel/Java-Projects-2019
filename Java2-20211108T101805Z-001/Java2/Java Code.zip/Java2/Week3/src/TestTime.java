import java.util.Scanner;

public class TestTime {

			public static void main(String[] args) {
				Scanner scan=new Scanner (System.in);
				
				Time s1=new Time();
				s1.printDetails();
				
				System.out.println("--------");
				s1.setMinutes(4);
				s1.setSeconds(9);
				s1.setHours(6);
				s1.printDetails();
		
			Time s2=new Time();
			s2.printDetails();
			
			System.out.println("--------");
			s2.setMinutes(254);
			s2.setSeconds(95);
			s2.setHours(6);
			s2.printDetails();

	}
}

