import java.util.*;
public class TestStudent {

	public static void main(String[] args) {
		Scanner scan=new Scanner (System.in);
		Student s1=new Student();
		System.out.println("Enter an Id: ");
		s1.setId(scan.nextInt());
		scan.nextLine();
		
		System.out.println("Enter a Name: ");
		s1.setName(scan.nextLine());
		
		System.out.println("Enter a Gender: ");
		s1.setGender(scan.nextLine().charAt(0));
		
		
		s1.printDetails();
		
		 System.out.println("----------------------");
		 
		Student s2=new Student();
		s2.printDetails();
		s2.setName("Nahid");
		s2.setId(100);
		System.out.println(s2.getName().toUpperCase());

}
}