import java.util.*;
public class TestPoint {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		Point p=new Point();
		p.printDetails();
		System.out.println("------------");
		
		Point p2=new Point(50);
		p2.printDetails();
		System.out.println("------------");
		
		Point p3=new Point(100,200);
		p3.printDetails();
		System.out.println("------------");
		
		Point p4=new Point();
		System.out.println("Enter x");
		int xx=scan.nextInt();
		p4.setX(xx);
		System.out.println("Enter y");
		p4.setY(scan.nextInt());
		p4.printDetails();
		System.out.println("------------");
			
	}

}
