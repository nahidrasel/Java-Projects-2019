
public class Point {
	private int x;
	private int y;
	//get method for x
	public int getX() {
		return x;
	}
	//set method for x
	public void setX(int x) {
		this.x=x;
	}
	//get method for y
		public int getY() {
			return y;
		}
		//set method for y
		public void setY(int y) {
			this.y=y;
		}
	
	//public ClassName(){}
	//Default constructor
	public Point() {
		x=5;
		y=7;
	}
	//parameterized constructor(with 1 input)
	public Point(int xValue) {
		x=xValue;
		y=0;
	}
	public Point(int xValue,int yValue) {
		x=xValue;
		y=yValue;
	}

	public void printDetails() {
		System.out.println("X "+x);
		System.out.println("Y "+y);
	}
}
