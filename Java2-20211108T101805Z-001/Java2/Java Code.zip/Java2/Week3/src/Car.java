
public class Car {

	//variables
	String regNo;
	String brandName;
	double price;
	String color;
	
	public void printDetails() {
		System.out.println("Registration No:" +regNo);
		System.out.println("Brand Name:" +brandName);
		System.out.println("Price:" +price);
		System.out.println("Color:"+color);
}
}
