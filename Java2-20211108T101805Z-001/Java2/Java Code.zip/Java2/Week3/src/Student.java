
public class Student {
	private static int id;
	private static String name;
	private static  char gender; // m for male , f for female

	public void setId(int idValue) {
		id = idValue;
	}

	public int getId() {
		return id;
	}

	public  void setName(String nameValue) {
		name = nameValue;
	}

	public String getName() {
		return name;
	}

	public  void setGender(char genderValue) {
		gender =genderValue;
	}

	public char getGender() {
		return gender;
	}

	public Student() {
		id = 0;
		name = "";
		gender = 0;

	}

	public Student(int idValue) {
		id = idValue;
		name = "";
		gender = 'm';

	}

	public Student(int idValue, String nameValue) {
		id = 0;
		name = "Unknown";
		gender = 'f';

	}

	public Student(int idValue, String nameValue, char gender) {
		id = 100;
		name = "known";
		gender = 'm';
	}

	public void printDetails() {
		System.out.println("ID :" + id);
		System.out.println("Name :" + name);
		System.out.println("Gender :" + gender);
	}

}
