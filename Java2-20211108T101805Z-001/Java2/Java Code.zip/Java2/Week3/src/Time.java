
public class Time {
	int hours;
	int minutes;
	int seconds;
	
	public void setMinutes(int minutesValue) {
		if (minutes >= 0 && minutes <= 60) {
			minutes = minutesValue;
		}
		else { 
this.minutes=0;
	}
	}
	public int getMinutes() {
		return minutes;
	}

	public void setSeconds(int secondsValue) {
		if (seconds >= 0 && seconds <= 60) {

			seconds = secondsValue;
		}
		else 
			this.seconds=0;
	}

	public int getSeconds() {
		return minutes;
	}
	
	public void setHours(int hoursValue) {
		if (hours >= 0 && hours <= 24) {
			hours = hoursValue;
		}
		else 
			this.hours=0;
	}

	public int getHours() {
		return hours;
	}


	public Time() {
		this(0,0,0); //this.seconds=0;
//this.setMinutes(0);
//this.setSeconds(0);
//this.setHours(0);;

	}

	public Time(int minutesValue) {
		this.setMinutes(seconds);
		this.setSeconds(0);
		this.setHours(0);;
	}

	public Time(int minutesValue, int seconds) {
		this.setMinutes(seconds);
		this.setSeconds(minutes);
		this.setHours(0);;
	}

	public Time(int minutesValue, int seconds, int hours) {
		this.setMinutes(minutes);
		this.setSeconds(seconds);
		this.setHours(hours);
	}

	public void printDetails() {
		System.out.println("Minutes:"+ minutes);
		System.out.println("Seconds: " + seconds);
		System.out.println("Hours  :" + hours);
	}

}