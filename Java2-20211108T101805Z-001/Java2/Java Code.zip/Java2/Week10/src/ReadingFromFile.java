import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

public class ReadingFromFile {

	public static void main(String[] args) {
		File myfile;
		PrintWriter pw;
		FileReader fr;
		BufferedReader br;

		try {
			myfile = new File("C:\\Users\\HP-NPC\\Desktop\\MyFiles\\data.txt");
			fr = new FileReader(myfile);
			br = new BufferedReader(fr);

			if (!myfile.exists()) {
				myfile.createNewFile();
				System.out.println("File not found");
			} else {
				int max = Integer.MAX_VALUE;
				int min = Integer.MIN_VALUE;
				int total = 0;
				int count = 0;
				String line = "";
				while ((line = br.readLine()) != null) {
					int number = Integer.parseInt(line.trim());

					if (number > max)
						max = number;

					if (number < min)
						min = number;

					total = total + number;
					count++;
				}
				double average = total / count;
				System.out.println("max" + max);
				System.out.println("min" + min);
				System.out.println("Total" + total);
				System.out.println("Average" + average);
			}
			System.out.println("Reading is finished");
			br.close();
			fr.close();
		} catch (IOException e) {
			System.out.println("Check the path ! ");
		}

	}

}
