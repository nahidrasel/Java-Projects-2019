import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

public class WritingToFile2 {
	public static void main(String[] args) {
		File myfile;
		PrintWriter pw;

		try {
			myfile = new File("C:\\Users\\HP-NPC\\Desktop\\MyFiles\\data.txt");
			pw = new PrintWriter(myfile);

			if (!myfile.exists()) {
				myfile.createNewFile();
				System.out.println("File is created");
			}
			/*
			 * pw.println("Hello");
			 *  pw.println("World"); pw.println("The sky is blue");
			 */
			// print random numbers

			Random rnd = new Random();
			for (int i = 1; i <= 200; i++) {
				pw.println(rnd.nextInt(300) + 1);
			}
			System.out.println("Writing is done");
			pw.close();

		} catch (IOException e) {
			System.out.println("Check the path");
		}
	}
}
