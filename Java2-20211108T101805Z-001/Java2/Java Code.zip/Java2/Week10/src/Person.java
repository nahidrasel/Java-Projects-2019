
public class Person {
	private String name;
	private char gender;
	private int age;
	private double grade;

	// constructor
	public Person(String name, char gender, int age, double grade) {
		super();
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.grade = grade;
	}

	// ToString
	public String toString() {
		return "Person name= " + name 
				+ ", gender= " + gender 
				+ ", age= " + age 
				+ ", grade= " + grade +" " ;
	}

	// get and set
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getGrade() {
		return grade;
	}

	public void setGrade(double grade) {
		this.grade = grade;
	}

}
