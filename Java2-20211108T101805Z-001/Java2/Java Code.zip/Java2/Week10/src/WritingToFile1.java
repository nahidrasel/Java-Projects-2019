
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WritingToFile1 {
	public static void main(String[] args) {
		File myfile;
		FileWriter fw;
		BufferedWriter bw;

		try {
			myfile = new File("C:\\Users\\HP-NPC\\Desktop\\MyFiles\\data.txt");
			fw = new FileWriter(myfile,true);
			bw = new BufferedWriter(fw);

			if (!myfile.exists()) {
				myfile.createNewFile();
				System.out.println("File is created");
			}
			bw.write("Hello\r\n");
			bw.write("My name is John\n");

			for (int i=0;i<=20; i++) {
				if (i%2==0) 
					bw.write(i+"\n");
				}
			System.out.println("Writing is done");

			bw.close();
			fw.close();

		} catch (IOException e) {
			System.out.println("Check the path");
		}
	}
}
