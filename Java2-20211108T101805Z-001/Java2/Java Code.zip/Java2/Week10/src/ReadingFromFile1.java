import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReadingFromFile1 {

	public static void main(String[] args) {
		File myfile;
		FileReader fr;
		BufferedReader br;

		try {
			myfile = new File("C:\\Users\\HP-NPC\\Desktop\\MyFiles\\info.txt");
			fr = new FileReader(myfile);
			br = new BufferedReader(fr);

			if (myfile.exists()) {
				String line = " ";
				while ((line = br.readLine()) != null) {
					// System.out.println(line = br.readLine());
					String[] tokens = line.split(",");
					String name = tokens[0];
					char gender = tokens[1].charAt(0);
					int age = Integer.parseInt(tokens[2]);
					double grade = Double.parseDouble(tokens[3]);
					Person p = new Person(name, gender, age, grade);
					System.out.println(p);
				}
			} else
				System.out.println("File not found");
			System.out.println("-----------------");
			System.out.println("Reading is finished");
			br.close();
			fr.close();
		} catch (IOException e) {
			System.out.println("Check the path");

		}

	}
}
