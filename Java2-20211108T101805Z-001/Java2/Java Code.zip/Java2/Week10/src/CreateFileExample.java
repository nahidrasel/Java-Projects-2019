import java.io.File;
import java.io.IOException;

public class CreateFileExample {

	public static void main(String[] args) {
		File myfile;
		try {
			myfile = new File("C:\\Users\\HP-NPC\\Desktop\\MyFiles\\data.txt");
			if (myfile.createNewFile())
				System.out.println("File is created");
			else
				System.out.println("File already exists");
		} catch (IOException e) {
			System.out.println("Check the path");
		}
	}

}
