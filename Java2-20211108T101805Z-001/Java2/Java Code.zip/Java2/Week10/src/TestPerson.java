import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class TestPerson {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		
	
		System.out.println("-------------------");
		System.out.println("Enter name:");
		String name=scan.nextLine();
		System.out.println("Enter gender:");
		char gender=scan.nextLine().charAt(0);
		System.out.println("Enter age:");
		int age=scan.nextInt();
		System.out.println("Enter mark:");
		double grade=scan.nextDouble();
		
		File myfile;
		FileWriter fw;
		BufferedWriter bw;

		try {
			myfile = new File("C:\\Users\\HP-NPC\\Desktop\\MyFiles\\info.txt");
			
			fw = new FileWriter(myfile,true);// with append
			bw = new BufferedWriter(fw);

			if (myfile.exists()) {
				bw.write("\r\n"+name+","+gender+","+age+","+grade);
			System.out.println("Writing is done");
			}
			bw.close();
			fw.close();

		} catch (IOException e) {
			System.err.println("Check the path");
		}
	}
}
