import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReadingFromFile2 {

	public static void main(String[] args) {
		File myfile;

		FileReader fr;
		BufferedReader br;

		try {
			myfile = new File("C:\\Users\\HP-NPC\\Desktop\\MyFiles\\info.txt");
			fr = new FileReader(myfile);
			br = new BufferedReader(fr);

			if (!myfile.exists()) {

			String line = " ";
			while ((line = br.readLine()) != null) {
				System.out.println(line = br.readLine());

			}
			System.out.println("Reading is finished");
			br.close();
			fr.close();
		} 
		}
		catch (IOException e) {
			System.out.println("Check the path");
		}

	}

}
