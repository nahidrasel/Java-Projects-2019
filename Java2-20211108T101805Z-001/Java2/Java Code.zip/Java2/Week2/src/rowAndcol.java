import java.util.*;
public class rowAndcol {
	public static void diagram(int row,int col) {
		for(int i=0;i<row;i++) {
			for(int j=0;j<col;j++) {
				System.out.print("* ");
			}
			System.out.println("\n");
			
		}
	}

	public static void main(String[] args) {
		int r,c;
		Scanner scan=new Scanner(System.in);
		diagram(2,4);
		
	}

}
