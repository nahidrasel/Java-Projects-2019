import java.util.*;
public class MethodTest {

	public class CircleComputation {
		private double radius;

		public CircleComputation(double r) {
				r= radius;
			}
		}

		public void perimeter() {
			double circlePerimeter = 2 * Math.PI * radius;
			System.out.println("The Perimeter is :" + circlePerimeter);
		}
		public void area() {
			double circleArea = Math.PI * radius * radius;
			System.out.println("The area is :" + circleArea);
		}

		public void displayAll() {
			System.out.println("The radius is :" + radius);
			this.perimeter();
			this.area();
		}
	}

