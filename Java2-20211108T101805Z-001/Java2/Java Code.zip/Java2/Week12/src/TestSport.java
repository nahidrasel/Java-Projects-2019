
public class TestSport {

	public static void main(String[] args) {
		Football f=new Football();
		System.out.println("FOOTBALL");
		System.out.println("Use ball="+f.usesABall());
		System.out.println("Indoor="+f.isPlayedIndoors());
		System.out.println("----------------");
	
		SnowSport s= new SnowSport();
		System.out.println("SNOW SPORT");
		
		System.out.println("Use ball="+s.usesABall());
		System.out.println("Indoor="+s.isPlayedIndoors());
		System.out.println("----------------");
		
		Skiing sk=new Skiing();
		System.out.println("SKIING");
		System.out.println("Use ball="+sk.usesABall());
		System.out.println("Indoor="+sk.isPlayedIndoors());
}
}
