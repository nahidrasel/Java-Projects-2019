
public interface Sport {
	public boolean usesABall();
	public boolean isPlayedIndoors();

}
