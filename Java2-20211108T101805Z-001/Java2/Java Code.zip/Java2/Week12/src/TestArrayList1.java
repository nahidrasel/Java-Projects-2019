import java.util.ArrayList;
import java.util.Scanner;

import javax.print.attribute.IntegerSyntax;

public class TestArrayList1 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		ArrayList<Integer> numbers = new ArrayList<Integer>();
		numbers.add(10);
		numbers.add(30);
		numbers.add(50);
		numbers.add(70);
		System.out.println("Size=" + numbers.size());

		// for each loop
		// for(TypeofArrayList anyName : ArrayListName)
		for (Integer num : numbers) {
			System.out.println(num);
		}
		System.out.println("--------------");
		numbers.remove(1);
		for (int i = 0; i < numbers.size(); i++) {
			System.out.println(numbers.get(i));
		}
		numbers.clear(); // for delete all array numbers
		//

		int number = 0;
		do {
			System.out.println("Enter a number:");
			number = scan.nextInt();
			if(number!=0)
			numbers.add(number);
		} while (number != 0);
		int sum = 0;
		int max = Integer.MIN_VALUE;
		int min = Integer.MAX_VALUE;

		for (Integer num : numbers) {
			if (num < min) {
				min = num;
			} else
				max = num;

			sum = sum + num;
		}

		System.out.println("The sum is: " + sum);
		System.out.println("Min:" + min);
		System.out.println("Max:" + max);

	}
}