
public interface PowerButton {
	//interface is a collection of method signature
	public void on();
	public void off();

}
