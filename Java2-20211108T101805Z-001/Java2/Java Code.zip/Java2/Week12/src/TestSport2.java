
public class TestSport2 {
	public static void main(String[] args) {

		Football f = new Football();
		System.out.println("FOOTBALL");
		if (f.isPlayedIndoors())
			System.out.println("Football is played indoors");
		else
			System.out.println("Football is not played indoors");

		if (f.usesABall())
			System.out.println("Football is used a ball");
		else
			System.out.println("Football is not used a ball");
		System.out.println("----------------");

		SnowSport s = new SnowSport();
		System.out.println("SNOW SPORT");
		if (s.isPlayedIndoors())
			System.out.println("Snow Sport is played indoors");
		else
			System.out.println("Snow Sport is not played indoors");
		if (s.usesABall())
			System.out.println("Snow Sport is used a ball");
		else
			System.out.println("Snow Sport is not used a ball");

		System.out.println("----------------");

		Skiing sk = new Skiing();
		System.out.println("SKIING");
		if (sk.isPlayedIndoors())
			System.out.println("Skiing is played indoors");
		else
			System.out.println("Skiing is not played indoors");
		if (sk.usesABall())
			System.out.println("Skiing is used a ball");
		else
			System.out.println("Skiing is not used a ball");
	}
}
