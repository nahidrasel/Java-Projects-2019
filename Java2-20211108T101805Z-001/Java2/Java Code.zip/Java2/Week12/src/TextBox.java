
public class TextBox {
	public static void main(String[] args) {
		Box<String> sString = new Box<String>("Hello");
		System.out.println(sString);
		System.out.println("---------------");

		Box<Integer> iInteger = new Box<Integer>(100);
		System.out.println(iInteger);
		System.out.println("-----------");

		Box<Boolean> bBoolean = new Box<Boolean>(true);
		System.out.println(bBoolean);
		System.out.println("--------------");

		Box<Character> cCharacter = new Box<Character>('A');
		System.out.println(cCharacter);
		System.out.println("-------------");
		Box<Double> dDouble = new Box<Double>(14.5);
		System.out.println(dDouble);
		System.out.println("----------------");

		Box<Float> fFloat = new Box<Float>(10.50f);
		System.out.println(fFloat);
		System.out.println("-------------------");
	}

}
