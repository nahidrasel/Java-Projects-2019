
public class Radio implements PowerButton {

	//Override
	public void on() {
		System.out.println("Radio is on ");
		
	}

	//.Override
	public void off() {
		System.out.println("Radio is off");
		
	}

}
