
public class Dog implements Animal{

	//Override
	public void eat() {
		System.out.println("Dog is eating Fish ");
		
	}

	//Override
	public void travel() {
		System.out.println("Dog is travelling to whangarai");
		
	}

	//Override
	public void makeSound() {
		System.out.println("Dog is barking Bow Bow");
		
	}

}
