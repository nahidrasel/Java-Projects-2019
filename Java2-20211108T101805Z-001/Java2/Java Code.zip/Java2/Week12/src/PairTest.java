
public class PairTest {

	public static void main(String[] args) {

		Pair<String> ps = new Pair<String>("happy", "sad");
		Pair<Double> pd = new Pair<Double>(2.5, 5.7);
		System.out.println(ps);
		System.out.println(pd);
		ps.setFirst("very");
		pd.setSecond(-3.4);
		System.out.println(ps);
		System.out.println(pd);
		Pair<String> ps2 = new Pair<String>("one", "two");
		Pair<Pair<String>> pps = new Pair<Pair<String>>(ps, ps2);
		System.out.println(pps);

		Person p1 = new Person("John");
		Person p2 = new Person("Amanda");
		Pair<Person> pp = new Pair<Person>(p1, p2);
		System.out.println(pp);

	}

}
