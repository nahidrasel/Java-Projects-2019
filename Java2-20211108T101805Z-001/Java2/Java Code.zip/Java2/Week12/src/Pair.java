
public class Pair<T> {
	// fields
	private T first;
	private T second;

	// constructor
	public Pair(T first, T second) {
		this.first = first;
		this.second = second;
	}

	// get and set
	public T getFirst() {
		return first;
	}

	public void setFirst(T first) {
		this.first = first;
	}

	public T getSecond() {
		return second;
	}

	public void setSecond(T second) {
		this.second = second;
	}

	// toString
	public String toString() {
		return "(" + first.toString() + "," + second.toString() + ")";
	}

}
