
public class TestDevice {

	public static void main(String[] args) {
		
		TV t = new TV();//create object from each class
		
		t.on();//call the methods(On & off)
		t.off();

		System.out.println("----------------");

		Radio r = new Radio();
		r.on();
		r.off();

		System.out.println("--------------");

		Phone p = new Phone();
		p.on();
		p.off();

		System.out.println("---------------");

	}

}
