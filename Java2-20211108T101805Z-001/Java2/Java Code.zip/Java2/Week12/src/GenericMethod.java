
public class GenericMethod {

	public static <T> void printArray(T[] array) {
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i] +" ");
		}
		System.out.println("\n");
	}

	public static void main(String[] args) {

		Integer[] intArray = { 1, 3, 5, 7, 9, 11, 13 };
		Double[] doubleArray = { 1.1, 2.2, 3.3, 4.4, 5.5 };
		String[] stringArray = { "One", "Two", "Three", "Four" };
		printArray(intArray);
		printArray(doubleArray);
		printArray(stringArray);
	}

}
