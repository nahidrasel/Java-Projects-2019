
public class Box<T> {
	private T myContent;

	// constructor

	public Box(T myContent) {
		this.myContent = myContent;
	}
	// set & get

	public T getMyContent() {
		return myContent;
	}

	public void setMyContent(T myContent) {
		this.myContent = myContent;
	}

	// toString
	public String toString() {
		return myContent+"";
	}

}
