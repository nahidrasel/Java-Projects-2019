
public class SnowSport implements Sport {

	//Override
	public boolean usesABall() {
		
		return false;
	}

	//Override
	public boolean isPlayedIndoors() {
		
		return false;
	}

}
