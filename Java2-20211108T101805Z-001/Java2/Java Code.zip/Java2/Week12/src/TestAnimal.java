
public class TestAnimal {

	public static void main(String[] args) {
		Cat c= new Cat();
		c.eat();
		c.travel();
		c.makeSound();
		System.out.println("-----------------");
		
		Dog g=new Dog();
		g.eat();
		g.travel();
		g.makeSound();
	}

}
