
public class Phone implements PowerButton {

	//Override
	public void on() {
		System.out.println("Phone is on");
		
	}

	//Override
	public void off() {
		System.out.println("Phone is off");
		
	}

}
