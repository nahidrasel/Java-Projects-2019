
public class Football implements Sport{

	@Override
	public boolean usesABall() {
		
		return true;
	}

	@Override
	public boolean isPlayedIndoors() {
		
		return false;
	}

}
