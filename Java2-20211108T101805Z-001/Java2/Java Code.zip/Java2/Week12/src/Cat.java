
public class Cat implements Animal {

	//Override
	public void eat() {
		System.out.println("Cat is eating Milk");
		
	}

	//Override
	public void travel() {
		System.out.println("Cat is travelling to queen street ");
		
	}

	//Override
	public void makeSound() {
		System.out.println("Cat is making sound MEO MEO");
		
	}

}
