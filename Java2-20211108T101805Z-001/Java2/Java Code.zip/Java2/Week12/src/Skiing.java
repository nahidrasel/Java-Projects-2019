
public class Skiing extends SnowSport {

	public boolean usesABall() {

		return false;
	}

	public boolean isPlayedIndoors() {
	
	return false;
	}
	}
