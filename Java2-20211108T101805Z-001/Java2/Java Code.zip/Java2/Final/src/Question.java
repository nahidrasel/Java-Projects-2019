public class Question {
	private int numberofLives;
	private int numberofGold;
	private boolean powerup;

//
	public Question() {
		this.setNumberofLives(3);
		this.numberofGold = 0;
		this.powerup = false;
	}

	// Override
	public String toString() {
		return "Question numberofLives= + numberofLives"
				+ "+numberofGold= + numberofGold + , powerup= + powerup";
	}

	public int getNumberofLives() {
		return numberofLives;
	}

	public void setNumberofLives(int nol) {
		if (nol >= 0 && nol <= 3)
			this.numberofLives = nol;
		else
			this.numberofLives = 0;
	}

	public int getNumberofGold() {
		return numberofGold;
	}

	public void setNumberofGold(int numberofGold) {
		this.numberofGold = numberofGold;
	}

	public boolean isPowerup() {
		return powerup;
	}

	public void setPowerup(boolean powerup) {
		this.powerup = powerup;
	}

}
