import java.util.Scanner;

public class Question2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int pos = 0;
		int neg = 0;
		int input;
		boolean readinput = true;
		while (readinput) {
			System.out.println("Enter Numbers:");
			input = scan.nextInt();
			if (input < 0)
				neg++;
			if (input > 0)
				pos++;
			if (input == 0)
				readinput = false;
		}
		System.out.println("Positve ="+ pos);
		System.out.println("Negative ="+ neg);
	}
}
