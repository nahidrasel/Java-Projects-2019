import java.util.PriorityQueue;
import java.util.Queue;

public class TestQueue3 {
	public static void main(String args[]) {
		Queue<Double> numbers = new PriorityQueue<Double>();// priority
		numbers.add(10.10);

		numbers.add(20.20);
		numbers.add(70.70);
		numbers.add(40.40);
		numbers.add(90.90);
		numbers.add(30.30);
		numbers.add(50.50);
		
		while (!numbers.isEmpty()) {
			System.out.println(numbers.remove());
		}

	}
}
