
public class TestPerson {

	public static void main(String[] args) {

		Person p = new Person("Nahid", "0225943095");
		System.out.println(p);// create object from each class

		p.getName();// call the methods( & )
		p.getPhoneNumber();
		p.setName("Keshav");
		p.setPhoneNumber("02258");

		System.out.println("----------------");

		PhoneBook pb = new PhoneBook();
		pb.addPerson(p);
		pb.removePerson(1);
		pb.printAllContact();
		pb.removeAllContact();
		System.out.println();

		System.out.println("--------------");

	}

}
