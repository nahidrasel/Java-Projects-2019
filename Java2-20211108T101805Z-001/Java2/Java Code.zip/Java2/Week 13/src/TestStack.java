import java.util.Stack;

public class TestStack {

	public static void main(String[] args) {
		Stack<Integer>numbers= new Stack<Integer>();
		numbers.push(10);
		numbers.push(20);
		numbers.push(30);
		numbers.push(40);
		numbers.push(50);
		numbers.push(60);
		
		while(!numbers.isEmpty()) {
			System.out.println(numbers.pop());
		}
	}

}
