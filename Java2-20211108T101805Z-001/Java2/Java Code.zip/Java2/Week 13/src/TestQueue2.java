import java.util.PriorityQueue;
import java.util.Queue;

public class TestQueue2 {
	public static void main(String args[]) {
		Queue<String> words = new PriorityQueue<String>();
		words.add("First");
		words.add("Apple");
		words.add("Zoo");
		words.add("Mike");
		words.add("Book");
		words.add("John");
		words.add("Last");
		words.add("Next");
		words.add("Bad");
		while (!words.isEmpty()) {
			System.out.println(words.remove());
		}

	}
}
