
public class TestArrayList3 {
	public static void main(String[] args) {

		PhoneBook pb = new PhoneBook();
		pb.printAllContact();

		Person p = new Person("John", "025454545");
		pb.addPerson(p);
		pb.addPerson(new Person("James", "056546565"));
		pb.addPerson(new Person("Jahid", "026546565"));
		pb.addPerson(new Person("Jobair", "0336546565"));
		pb.printAllContact();

		System.out.println("\n-----------Searching----------");
		boolean result = pb.searchPerson(p);
		if (result == true) {
			System.out.println("Person Found");
		} else
			System.out.println("Person Not Exist");
		System.out.println("------------------");
		System.out.println("\n-----------Removing index 2-------------");
		pb.removePerson(2);
		pb.printAllContact();
		System.out.println("\n-----------Removing all------------");
		pb.removeAllContact();
		System.out.println("------------------------------");

	}

}
