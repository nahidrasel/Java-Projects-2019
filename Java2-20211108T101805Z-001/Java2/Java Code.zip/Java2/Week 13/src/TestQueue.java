import java.util.LinkedList;
import java.util.Queue;

public class TestQueue {

	public static void main(String[] args) {
		Queue<Integer>numbers= new LinkedList<Integer>();
		numbers.add(10);
		numbers.add(30);
		numbers.add(50);
		numbers.add(70);
		numbers.add(90);
		
		while(!numbers.isEmpty()) {
			System.out.println(numbers.remove());
		}	
	}
}
