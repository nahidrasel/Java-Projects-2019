import java.util.Stack;

public class TestStack2 {
	public static void main(String[] args) {
	Stack<String>words=new Stack<String>();
	words.push("One");
	words.push("Two");
	words.push("Three");
	words.push("Four");
	words.push("Five");
	words.push("Six");
	
	
	while(!words.isEmpty()) {
		System.out.println(words.pop());
	}

}
}
