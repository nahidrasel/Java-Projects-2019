import java.util.ArrayList;
import java.util.Collections;

public class TestArrayList4 {

	public static void main(String[] args) {
		ArrayList<Double>marks= new ArrayList<Double>();
		marks.add(85.5);
		marks.add(93.5);
		marks.add(65.7);
		marks.add(84.7);
		marks.add(78.6);
		marks.add(88.8);
		for (Double s : marks) {
			System.out.println(s);
		}
		System.out.println("------------Remove one line ---------");
		
		marks.remove(3);
		
		for(int i=0;i<marks.size();i++) {
			System.out.println(marks.get(i));
		}
		
		System.out.println("----------------");
		
		//This will sort the arrayList
		Collections.sort(marks);
		
		for (Double d : marks) {
			System.out.println(d);
		}
		marks.clear();
		}

}
