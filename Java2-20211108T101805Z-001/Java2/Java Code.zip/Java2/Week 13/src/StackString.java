import java.util.Scanner;
import java.util.Stack;

public class StackString {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Stack<String> words = new Stack<String>();
		System.out.println("Enter a word:");
		String input = "";
		do {
			input = scan.nextLine();
			if (!input.equalsIgnoreCase("stop"))
				words.push(input);
		}
		while (!input.equalsIgnoreCase("Stop"));

		while (!words.isEmpty()) {
			System.out.println(words.pop().toUpperCase());
		}
	}
}
