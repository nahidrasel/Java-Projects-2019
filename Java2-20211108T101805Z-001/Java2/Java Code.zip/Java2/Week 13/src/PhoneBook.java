import java.util.ArrayList;

public class PhoneBook {
	private ArrayList<Person> list;
	public PhoneBook() {
		list = new ArrayList<Person>();
	}
	public void addPerson(Person p) {
		if(p!=null) {
		list.add(p);	
	}
	}
	public void removePerson(int index) {
		if(index>=0  && index<list.size()) {
			list.remove(index);
		}
	}
	public void removeAllContact() {
		list.clear();
	}
	public void printAllContact() {
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));	
		}
	}
	public boolean searchPerson(Person p) {
		for(int i=0;i<list.size();i++) {
			if(list.get(i).getName().equalsIgnoreCase(p.getName())&&list.get(i).getPhoneNumber().equalsIgnoreCase(p.getPhoneNumber()))
				return true;
			}
				return false;		
			}
	}
