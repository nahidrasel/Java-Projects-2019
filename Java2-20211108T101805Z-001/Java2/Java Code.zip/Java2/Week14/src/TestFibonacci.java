
public class TestFibonacci {
	// 0,1,1,2,3,5,8
	public static int fib(int number) {
		// 1,1,2,3,5,8,13,21,.............
		int f1 = 1;
		int f2 = 1;
		int fn = 0;
		for (int i = 3; i <= number; i++) {
			fn = f1 + f2;
			f1 = f2;
			f2 = fn;
		}
		return fn;
	}

	public static int fibRec(int number) {
		if (number == 0)
			return 0;
		if (number == 1)
			return 1;
		return fib(number - 1) + fib(number - 2);
	}

	public static int fibNew(int number) {
		if (number <= 2)
			return 1;
		return fibNew(number - 1) + fibNew(number - 2);
	}

	public static void main(String[] args) {
		System.out.println(fib(10));
		System.out.println(fibRec(10));
		System.out.println(fibNew(10));
	}
}