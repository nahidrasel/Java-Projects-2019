
public class TestFactorial {

	public static int fact(int number) {
		int result = 1;
		for (int i = 1; i <= number; i++) {

			result = result * i;
		}
		return result;
	}

	public static int factRec(int number) {
		if (number == 1)
			return 1;

		return number * factRec(number - 1);
	}

	public static void main(String[] args) {
		System.out.println(fact(3));
		System.out.println(factRec(3));
	}

}
