
public class TestSummation {

	public static int sum(int number) {
		int total = 0;
		for (int i = 1; i <= number; i++) {
			total = total + i;
		}
		return total;
	}

	// Recursive Method
	// Number repeating method
	public static int sumRec(int number) {
		// termination condition
		// stop condition
		// base case
		if (number == 1)
			return 1;
		return number + sumRec(number - 1);
	}

	public static void main(String[] args) {
		System.out.println(sum(10));
		System.out.println(sumRec(10));
	}

}
