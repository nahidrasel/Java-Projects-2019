
public class Summation {

	public static void main(String[] args) {
		

	}

}
