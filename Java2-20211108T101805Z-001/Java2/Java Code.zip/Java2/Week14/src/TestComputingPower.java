
public class TestComputingPower {

	public static int power(int base, int exp) {
		int total = 1;
		for (int i = 1; i <= exp; i++) {
			total = total * base;

		}
		return total;
	}

	public static int powerRec(int base, int exp) {
		if (exp == 0)
			return 1;
		return base * powerRec(base, exp - 1);
	}

	public static void main(String[] args) {
		System.out.println(power(2, 4));
		System.out.println(powerRec(2, 4));
	}
}
