#include<stdio.h>
int main()
{
	char ch;
	printf("Enter your name:");
	ch=getchar();
	printf("The first letter of your name is:%c\n",ch);
	return 0;

}
