#include <stdio.h>
int main()
{
	int i;
	scanf("%d",&i);
	while (i<=500) {
		i=i+1;
		if(i%2==0) {
			continue ;
			
		}
		printf("%d\n",i);
	}
return 0;
}
