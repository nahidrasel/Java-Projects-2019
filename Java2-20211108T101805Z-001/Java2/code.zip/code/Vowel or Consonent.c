#include<string.h>
int main()
{
char ara[i];
int i=0;
while(ara[i]!='\0'){
        gets(ara[i]);
    i++;
}
puts(ara);
return 0;
}
