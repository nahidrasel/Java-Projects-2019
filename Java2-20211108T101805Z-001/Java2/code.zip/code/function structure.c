#include<stdio.h>
int add(int a,int b);
int main()
{
int num1,num2,result;
printf("Enter two numbers :\n");
scanf("%d%d",&num1,&num2);
result=add(num1,num2);
printf("sum is :%d\n",result);
return 0;
}
int add(int a,int b)
{
    int result=a+b;
    return result;
    }

