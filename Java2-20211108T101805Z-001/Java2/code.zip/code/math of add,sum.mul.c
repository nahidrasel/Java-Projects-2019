#include<stdio.h>
int main()
{
	int n;
	printf("Enter the value of n:");
	scanf("%d",&n);
	if (n<0) {
	printf("The number is over than 1hundreds\n");
}
	else if (n>0) {
	printf("The number is over than 1hundreds\n");
	}
	else if(n==0) {
		printf("the number is zero\n");
	}
	return 0;
}

