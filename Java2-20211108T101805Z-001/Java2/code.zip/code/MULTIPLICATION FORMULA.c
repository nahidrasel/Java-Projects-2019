#include <stdio.h>
int main(void)
{
	double celsius,farenheit;
	printf("Enter the temperature in celsius:");
	scanf("%lf",&celsius);
	farenheit=1.8*celsius+32;
	printf("Tempareture in farenheit is:%lf\n",farenheit);
	return 0;
	}

