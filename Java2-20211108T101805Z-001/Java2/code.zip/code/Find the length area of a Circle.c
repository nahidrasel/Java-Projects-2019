#include<stdio.h>
int main()
{
	double pi,r,area;
	pi=3.1416;
	printf("Enter the length of a circle:");
	scanf("%lf",&r);
	area=pi*r*r;
	printf("The Area of a circle is :%00.2lf",area);
	return 0;
	}
