#include <stdio.h>
int main()
{
char str1[]= "bangla", str2[]= "desh";
strcat(str1,str2);
printf("%s\n", str2);
return 0;
}
