#include <stdio.h>
int main()
{
int n;
scanf("%d",&n);
int i;
scanf("%d",&i);
for (i <= 10 ; ;) {
printf("%d X %d = %d\n", n, i, n*i);
i++;
}
return 0;
}
