#include<stdio.h>
int main()
{
	int m=0,n;
	int i;
	for(n=1;n++;) {
		printf("%d*%d=%d\n",n,i,m);
		if(n>1) {
			break;
		}
	}
	for(i=1;i<=10;i++) {
		m=m+n;
		printf("%d*%d=%d\n",n,i,m);
	}
	return 0;

}
