int main()
{
    char ch;
    scanf("%c",&ch);
          if((ch>='a'&&ch<='z') || (ch>='A'&&ch<='Z')) {
        printf("it's alphabet",ch);
}
    else if(ch>='0' && ch<='9'){
            printf("It's a digit",ch);
    }

else {
    printf("Its a special character",ch);
}

}
