#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	scanf("%d",&i);
	for (; n>=10;n++) {
		printf("%d+%d=%d\n",n,n,n+n);
		if(n>100) {
			break;
		}
	}
	for (; i>=1;n++) {
		printf("%d+%d=%d\n",n,i,n+i);
		if(n>10) {
			break;
		}
	}
	return 0;
	
}
