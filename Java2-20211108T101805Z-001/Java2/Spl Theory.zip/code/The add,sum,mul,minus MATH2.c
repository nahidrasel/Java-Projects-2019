#include<stdio.h>
int main()
{
	int num1,num2;
	int char sign;
	printf("Enter a number:");
	scanf("%d",&num1);
	printf("Enter a sign:");
	scanf("%c",&sign);
	printf("Enter another number:");
	scanf("%d",&num2);

	return 0;
}



