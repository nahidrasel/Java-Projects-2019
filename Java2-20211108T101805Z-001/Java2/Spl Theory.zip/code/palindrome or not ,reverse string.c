#include<string.h>
int main()
{
char str1[30]="madam";
char str2[30];
int k=0,j,i=0,m;
int len=0;
len=strlen(str1);
printf("%d ",len);
puts(str1);
for(j=len-1;j>=0;j--){
        str2[k]=str1[j];
k++;
}
puts(str2);
int flag=1;
for(m=0;m<k;m++){
        if(str1[m]==str2[m]){
            flag=1;
        }
        else{
            flag=0;
        }
}
        if(flag==1){
                printf("Palindrome");
        }
        else {printf("Not palindrome");
        }
}
