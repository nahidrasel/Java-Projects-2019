void swap(int* i,int* j){
int temp=*i;
*i=*j;
*j=temp;
}
int main(){
int a,b;
scanf("%d%d",&a,&b);
swap(a,b);
printf("%d %d",a,b);
}
