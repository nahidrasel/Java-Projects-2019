#include<stdio.h>
int add(int a,int b);
int main()
{
int num1,num2,num3,result;
printf("Enter two numbers :\n");
scanf("%d%d",&num1,&num2);
result=add(num1,num2);
printf("sum is :%d",result);
return 0;
}
int add(int a ,int b)
{
int sum;
sum=a+b;
return sum;
}


