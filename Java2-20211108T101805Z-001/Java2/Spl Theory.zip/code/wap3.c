int min(int arr[]){
    int i;
int min=arr[0];
for(i=0;i<2;i++){
if(min>arr[i]){
min=arr[i];
}
}
printf("%d",min);
}
int main(){
    int n;
    scanf("%d",&n);
int arr[n];
int i;
for(i=0;i<n;i++){
scanf("%d",&arr[i]);
}
min(arr[i]);
}
