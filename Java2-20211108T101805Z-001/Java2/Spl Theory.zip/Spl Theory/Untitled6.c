int main()
{
int taka;
float bill=0;
scanf("%d",&taka);
switch(taka) {
    case 0 :
    case 99 : {
    bill=taka-(taka*5/100);
    break;
    }
case 100:
case 190:
    {
bill=taka-(taka*7.5/100);
break;
}
case 200:
case 290:
    {
bill=taka-(taka*10/100);
break;
}
default :{
    bill=taka-(taka*15/100);
    break;
}
}
printf("%0.2f",bill);
}

