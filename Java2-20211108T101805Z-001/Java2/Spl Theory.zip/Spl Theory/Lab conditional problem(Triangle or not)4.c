#include<stdio.h>
int main()
{
   int num;
   scanf("%d",&num);
   if(num/2)
   {
       printf("it,s a power of 2");
       return 0;
}
}
