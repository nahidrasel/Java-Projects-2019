#include<stdio.h>
int main()
{
int color;
scanf("%d",&color);
if(color%4!=0)
{
printf("Red\n");
}
else if(color<45 && color>=34)
{
printf("Green\n");
}
if(color%2 || color)
{
printf("Blue\n");
}
if(color>=0 && color<5)
{
printf("Orange\n");
}
else if(color<=0 && color<=90)
{
printf("Yellow \n");
}
else
{
printf("Purple");
}
return 0;
}
