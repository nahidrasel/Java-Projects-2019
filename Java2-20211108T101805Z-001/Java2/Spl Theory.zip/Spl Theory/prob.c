int main()
{
    int num;
    scanf_s("%d",&num);
    if(num%2==0 || num%5==0 ) {
    printf("Num is divisor by 2 and 5");
    }
    else if(num%5==0){
    printf("Num is divisor by 5");
    }
    else if(num%2==0){
    printf("Num is Divisor by 2 and 5");
    }
    else {
            ("sorry");
        }
        }
