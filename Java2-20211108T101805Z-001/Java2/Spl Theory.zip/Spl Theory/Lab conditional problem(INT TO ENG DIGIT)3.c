#include<stdio.h>
int main()
{
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);
    if((a+b+c)==180) {
        printf("This is a triangle");
    }
    else {
        printf("This is not a triangle");
    }
    return 0;
}
