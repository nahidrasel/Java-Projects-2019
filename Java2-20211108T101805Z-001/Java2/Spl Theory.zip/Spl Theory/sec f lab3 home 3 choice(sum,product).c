int main()
{
    int num;
    scanf("%d",&num);
    if(num>0){
            printf("It's a non zero positive number and ");
        if(num%2==0){
        printf("it's a even number");
}
else if("num%2==1"){
        printf("It's a odd number");
}
    }
else if (num<=0 ){
    printf("Its a non zero negative number");
}
}
