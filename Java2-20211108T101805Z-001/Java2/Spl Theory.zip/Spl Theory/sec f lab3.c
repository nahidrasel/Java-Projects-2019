#include<stdio.h>
int main()
{
    float celsius,farenheit;
    printf("Enter temperature in celsius:");
    scanf("%f",&celsius);
    farenheit=((9*celsius)+160)/5;
    printf("The temperature in farenheit is %f",farenheit);
    }

