#include <stdio.h>
int main() {
int a, b, x = 2, y = 3;
a = x--;
printf("a = %d\n",a);
x++;
printf("x = %d\n",x);
b = --y;
printf("y = %d\n",y);
printf("%d\n", (a>b || x<=y) );
if(! ( 2*a >= b || x == y ) )
printf("%d\n",2*a);
else
printf("%d\n",3*b);
return 0;
}
