int main()
{
    int i,num1,num2;
    printf("Enter two numbers:");
    scanf("%d%d",&num1,&num2);
    for(num1<num2;num1<num2;num1++)
    {
        printf("%d\t",num1);
    }
        if(num1==2)
        {
            printf("%d",num1);
        }
        else printf("%d",num1);

    }
