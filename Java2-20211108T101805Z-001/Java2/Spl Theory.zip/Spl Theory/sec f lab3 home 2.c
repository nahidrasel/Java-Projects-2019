int main()
{

    int i,f=1,num;
    scanf("%d",&num);
    for(i=1;i<=num;i++)
    {
        f=f*i;
    printf("%d",f);
}
}
