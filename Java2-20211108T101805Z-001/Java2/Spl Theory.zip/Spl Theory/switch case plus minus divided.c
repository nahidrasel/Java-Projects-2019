int main()
{
int a,b,choice,r;
scanf("%d",&a);
scanf("%d",&b);
scanf("%d",&choice);
switch(choice) {
case 1: r=a+b;
break;
case 2: r=a-b;
break;
case 3: r=a%b;
break;
default : r=a/b;
}
printf("%d",r);
}
