#include<stdio.h>
int main()
{
    int a;
    printf("Enter your mark:");
    scanf("%d",&a);
    if(a>=90&a==100) {
        printf("Your Grade is A(Plain)");
    }
    else if(a>=86&&a<=89) {
        printf("Your Grade is A-(Minus");
    }
    else if(a>=82&&a<=85) {
        printf("Your Grade is B+(Plus)");
    }
    else if(a>=78&&a<=81) {
        printf("Your Grade is B(Plain))");
    }
    else if(a>=74&&a<=77) {
        printf("Your Grade is B-(Minus)");
    }
    else if(a>=73&&a<=70) {
        printf("Your Grade is C+(Plus)");
    }
    else if(a>=66&&a<=69) {
        printf("Your Grade is C(Plain)");
    }
    else if(a>=62&&a<=65) {
        printf("Your Grade is C-(Minus)");
    }
    else if(a>=58&&a<=61) {
        printf("Your Grade is D+(Plus)");
    }
    else if(a>=55&&a<=57) {
        printf("Your Grade is D(Plain)");
    }
    else {
        printf("FAIL");
    }
}
