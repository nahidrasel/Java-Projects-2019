#include<stdio.h>
int main()
{
int a;
scanf("%d",&a);
if(a){
printf("a isn,t equal to zero");
}
if (!a)
{
printf("a is zero");
}
}
