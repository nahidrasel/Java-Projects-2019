int main()
{
    int a,b,c,sum;
    scanf("%d%d%d",&a,&b,&c);
    if((a>0 &&a <=180)||(b>0&&b<=180)||(c>0&&c<=180))
    {
        sum=a+b+c;
        if(sum==180){
        printf("%d is triangle",sum);
    }
    else {
            printf("%d is not triangle",sum);
}
    }
}
