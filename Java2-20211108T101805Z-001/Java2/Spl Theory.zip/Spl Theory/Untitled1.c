#include <stdio.h>
int main()
{
int x=5;
switch(x!=0)
{
case 0:
printf("Red");
break;
case 1:
printf("Green ");
break;
default:
printf("Blue");
break;
}
return 0;
}
