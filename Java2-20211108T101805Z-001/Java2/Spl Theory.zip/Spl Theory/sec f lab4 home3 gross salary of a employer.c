int main()
{
int slry,gr_salary,hs_rent,mdc;
printf("Enter a salary:");
scanf("%d",&slry);
if(slry<=10000) {
             hs_rent=slry*30/100;
             mdc=slry*10/100;
             gr_salary=slry+hs_rent+mdc;
             printf("Gross salary is %d",gr_salary);
}
else if(slry>10000&&slry<=20000) {
             hs_rent=slry*40/100;
             mdc=slry*20/100;
             gr_salary=(slry+hs_rent+mdc);
             printf("Gross salary is %d",gr_salary);
}
 else if(slry>20000) {
        hs_rent=slry*60/100;
        mdc=slry*25/100;
        gr_salary=slry+hs_rent+mdc;
        printf("Gross salary is %d",gr_salary);
}
}
