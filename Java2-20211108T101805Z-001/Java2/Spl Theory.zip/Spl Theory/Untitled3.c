#include<stdio.h>
#include<math.h>
int main()
{
    char ch;
    float 2nd,int Nnm;
    scanf("%c %lf",&ch,&n2dnNum);
    n2dnNum%15 ;
     printf("Ans=%lf\n",n2dnNum);
}
