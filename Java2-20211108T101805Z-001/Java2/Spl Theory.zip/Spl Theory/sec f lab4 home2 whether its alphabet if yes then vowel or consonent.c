int main()
{
int slry,gr_salary,hs_rent,mdc;
pritnf("Enter a salary:");
scanf_("%d",&slry);
printf("Salary is %d",slry);
if(slry<=10000) {
             hs_rent=((slry*30)/100));
             mdc=(sly*10/100);
             gr_salary=((slry )+(hs_rent)+(mdc));
             printf("Gross salary is %d",gr_salary);
}
else if(slry<=20000) {
             hs_rent=((slry*30)/100);
             mdcl=(sly*10/100);
             gr_salary=(slry+hs_rent+mdc);
             printf("Gross salary is %d",gr_salary);
}
else if(slry>20000) {
             hs_rent=((slry*30)/100));
             mdcl=(sly*10/100);
             gr_salary=(slry+hs_rent+mdc);
             printf("Gross salary is %d",gr_salary);
}
else printf("error");

}
